"""Pure portfolio rules. No network, UI, or brokerage operations."""
from collections import defaultdict
from datetime import datetime, timezone
from decimal import Decimal, ROUND_FLOOR
from math import isfinite

MIN_VOTES = 3
MAX_HOLDINGS = 10
WEEK_SECONDS = 7 * 24 * 60 * 60


def normalized_allocations(scores):
    """Largest-remainder rounding, so displayed percentages total exactly 100."""
    total = sum(scores, Decimal(0))
    if total <= 0:
        return []
    exact = [s / total * 10000 for s in scores]
    basis_points = [int(n.to_integral_value(rounding=ROUND_FLOOR)) for n in exact]
    order = sorted(range(len(scores)), key=lambda i: (-(exact[i] - basis_points[i]), i))
    for i in order[:10000 - sum(basis_points)]:
        basis_points[i] += 1
    return [v / 100 for v in basis_points]


def build_portfolio(records, listings):
    ids = [r['id'] for r in records]
    if len(ids) != len(set(ids)):
        raise ValueError('Duplicate source portfolio IDs')
    if any(not isinstance(r['assets_usd'], (int, float)) or not isfinite(r['assets_usd']) or r['assets_usd'] <= 0 for r in records):
        raise ValueError('Every source needs a positive asset value')
    total = sum(Decimal(str(r['assets_usd'])) for r in records)
    if total <= 0:
        raise ValueError('No assets available')
    contributions = defaultdict(list)
    weights = {}
    for record in records:
        weights[record['id']] = float(Decimal(str(record['assets_usd'])) / total * 100)
        # A company cannot receive two votes from the same source, even with two share classes.
        for key in set(record.get('stock_keys', [])):
            contributions[key].append(record)
    ranked = []
    for key, parents in contributions.items():
        listing = listings.get(key, {})
        score = sum(Decimal(str(r['assets_usd'])) for r in parents) / total
        eligible = bool(listing.get('eligible'))
        count = len(parents)
        ranked.append({
            'key': key, 'name': listing.get('name', key), 'ticker': listing.get('ticker', '—'),
            'exchange': listing.get('exchange', 'Unlisted / OTC'),
            'votes': count, 'score_pct': float(score * 100), '_score': score,
            'eligible': eligible and count >= MIN_VOTES,
            'reason': 'No U.S. exchange listing' if not eligible else (f'Needs {MIN_VOTES - count} more vote(s)' if count < MIN_VOTES else 'Qualified'),
            'contributors': [r['id'] for r in parents],
        })
    ranked.sort(key=lambda x: (-x['_score'], x['name'].casefold(), x['key']))
    selected = [r.copy() for r in ranked if r['eligible']][:MAX_HOLDINGS]
    allocations = normalized_allocations([r['_score'] for r in selected])
    for row, pct in zip(selected, allocations):
        row['allocation_pct'] = pct
    for row in ranked + selected:
        row.pop('_score', None)
    return {
        'total_assets_usd': float(total), 'source_count': len(records),
        'selected': selected, 'ranked': ranked, 'fund_weights': weights,
        'min_votes': MIN_VOTES, 'max_holdings': MAX_HOLDINGS,
        'qualified_count': sum(r['eligible'] for r in ranked),
        'top_two_allocation': sum(r['allocation_pct'] for r in selected[:2]),
        'undated_asset_count': sum(not r.get('asset_date') for r in records),
    }


def freshness(last_scan, now=None):
    now = now or datetime.now(timezone.utc)
    if not last_scan:
        return {'needs_scan': True, 'age_days': None, 'reason': 'seed'}
    stamp = datetime.fromisoformat(last_scan)
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=timezone.utc)
    age = max(0, (now - stamp).total_seconds())
    return {'needs_scan': age > WEEK_SECONDS, 'age_days': age / 86400, 'reason': 'overdue' if age > WEEK_SECONDS else 'current'}

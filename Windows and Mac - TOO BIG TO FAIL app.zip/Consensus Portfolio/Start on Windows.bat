@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 launch.py
    goto finished
)
where python >nul 2>nul
if not errorlevel 1 (
    python launch.py
    goto finished
)
echo Python 3.9 or newer is required. Install Python and enable Add Python to PATH.
pause
exit /b 1
:finished
if errorlevel 1 pause
endlocal

"""Local research app. A rebalance updates the model, never submits trades."""
import copy
import json
import os
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

from engine import build_portfolio, freshness
from sources import exchange_directory, resolve_holdings, scan_record

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
STATE = DATA / 'state.json'
app = Flask(__name__, static_folder=str(ROOT / 'static'), static_url_path='/static')
lock = threading.RLock()
job = {'status': 'idle', 'completed': 0, 'total': 0, 'failures': [], 'updated': 0}


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def load_state():
    return json.loads((STATE if STATE.exists() else DATA / 'seed.json').read_text())


def atomic_write(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    os.replace(temp, path)


def run_scan():
    global job
    state = load_state()
    try:
        directory = exchange_directory()
        aliases = state['aliases']
        updated, listings, failures = [], {}, []
        with lock:
            job['phase'] = 'Scanning holdings and fund assets'
        with ThreadPoolExecutor(max_workers=6) as pool:
            futures = {pool.submit(scan_record, record): record for record in state['records']}
            for future in as_completed(futures):
                old = futures[future]
                try:
                    record, found = resolve_holdings(future.result(), directory, aliases)
                    updated.append(record)
                    listings.update(found)
                except Exception as exc:
                    failures.append({'id': old['id'], 'message': str(exc)[:220], 'url': old['scan_url']})
                with lock:
                    job.update(completed=len(updated) + len(failures), updated=len(updated), current=old['id'], failures=copy.deepcopy(failures))
        attempt = {'finished_at': utc_now(), 'updated': len(updated), 'total': len(state['records']), 'failures': failures}
        if failures:
            # Keep both the previous portfolio AND its original freshness timestamp.
            state['last_attempt'] = attempt
            with lock:
                atomic_write(STATE, state)
                atomic_write(DATA / 'last_scan_attempt.json', {'attempt': attempt, 'refreshed_records': updated, 'listings': listings})
                job.update(status='failed', phase='Incomplete scan · previous allocation retained', finished_at=attempt['finished_at'])
            return
        candidate = {**state, 'records': sorted(updated, key=lambda r: r['id']), 'listings': listings,
                     'last_successful_scan': attempt['finished_at'], 'last_attempt': attempt,
                     'snapshot_label': 'Public-source scan'}
        build_portfolio(candidate['records'], candidate['listings'])
        with lock:
            atomic_write(STATE, candidate)
            history = DATA / 'history'
            history.mkdir(exist_ok=True)
            atomic_write(history / (job['id'] + '.json'), candidate)
            job.update(status='complete', phase='Scan complete · allocation updated', finished_at=attempt['finished_at'])
    except Exception as exc:
        failure = {'id': 'Scan', 'message': str(exc)[:220]}
        with lock:
            job.update(status='failed', phase='Scan could not complete · previous allocation retained', failures=[failure], finished_at=utc_now())
            state['last_attempt'] = {'finished_at': job['finished_at'], 'updated': 0, 'total': len(state['records']), 'failures': [failure]}
            atomic_write(STATE, state)


@app.get('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')


@app.get('/api/state')
def state_api():
    with lock:
        state = load_state()
        response = {
            'portfolio': build_portfolio(state['records'], state['listings']),
            'records': state['records'], 'last_successful_scan': state['last_successful_scan'],
            'freshness': freshness(state['last_successful_scan']), 'snapshot_label': state['snapshot_label'],
            'seed_date': state['seed_date'], 'last_attempt': state['last_attempt'],
            'excluded_sources': state['excluded_sources'], 'job': copy.deepcopy(job),
        }
    return jsonify(response)


@app.post('/api/rebalance')
def rebalance():
    global job
    # A third-party website must not be able to trigger scans on the local server.
    origin = request.headers.get('Origin')
    if origin and origin.rstrip('/') != request.host_url.rstrip('/'):
        return jsonify(error='Origin not allowed'), 403
    with lock:
        if job['status'] == 'running':
            return jsonify(error='A scan is already running', job=job), 409
        count = len(load_state()['records'])
        job = {'id': uuid.uuid4().hex, 'status': 'running', 'phase': 'Verifying U.S. exchange listings',
               'completed': 0, 'updated': 0, 'total': count, 'failures': [], 'started_at': utc_now(), 'current': ''}
        threading.Thread(target=run_scan, daemon=True).start()
        return jsonify(job), 202


@app.get('/api/export')
def export():
    state = load_state()
    result = build_portfolio(state['records'], state['listings'])
    response = jsonify({'generated_at': utc_now(), 'last_successful_scan': state['last_successful_scan'],
                        'rules': {'top_direct_holdings': 2, 'min_votes': 3, 'max_stocks': 10, 'us_exchange_only': True,
                                  'fund_weight': 'fund assets / total reported assets', 'stock_score': 'sum of contributing fund weights',
                                  'allocation': 'stock score / sum of selected stock scores'},
                        'snapshot_label': state['snapshot_label'], 'portfolio': result, 'sources': state['records'],
                        'excluded_sources': state['excluded_sources']})
    response.headers['Content-Disposition'] = 'attachment; filename="too-big-to-fail-portfolio.json"'
    return response


@app.after_request
def headers(response):
    response.headers['Cache-Control'] = 'no-store'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Content-Security-Policy'] = "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'"
    return response


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=int(os.environ.get('PORT', '8765')), threaded=True, debug=False)

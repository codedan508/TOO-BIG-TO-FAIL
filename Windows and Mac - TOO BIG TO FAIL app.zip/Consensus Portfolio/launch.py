"""Set up, start and open the local app on macOS or Windows. Standard library only."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parent

def ready(url):
    try:
        with urllib.request.urlopen(url + '/api/state', timeout=1) as response:
            state = json.load(response)
        return all(key in state for key in ('portfolio', 'records', 'last_successful_scan'))
    except (OSError, ValueError, urllib.error.URLError):
        return False

def environment():
    python = ROOT / '.venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    if not python.exists():
        print('Creating the Python environment...', flush=True)
        subprocess.run([sys.executable, '-m', 'venv', str(ROOT / '.venv')], check=True)
    check = subprocess.run([str(python), '-c', 'import flask, bs4, pypdf'], capture_output=True)
    if check.returncode:
        print('Installing dependencies...', flush=True)
        command = [str(python), '-m', 'pip', 'install', '--find-links', str(ROOT / 'wheels'), '-r', str(ROOT / 'requirements.txt')]
        offline = subprocess.run(command + ['--no-index'])
        if offline.returncode:
            print('Downloading dependencies for this Python/platform...', flush=True)
            subprocess.run(command, check=True)
    return python

def main():
    if sys.version_info < (3, 9):
        raise RuntimeError('Install Python 3.9 or newer, then run this launcher again.')
    parser = argparse.ArgumentParser(description='Launch Consensus Portfolio on localhost:8765.')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--no-browser', action='store_true', help='Start the server without opening a browser.')
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        raise RuntimeError('Port must be between 1 and 65535.')
    url = 'http://127.0.0.1:' + str(args.port)
    if ready(url):
        print('Consensus Portfolio is already running: ' + url, flush=True)
        if not args.no_browser:
            webbrowser.open(url)
        return 0
    python = environment()
    env = dict(os.environ, PORT=str(args.port))
    print('Starting Consensus Portfolio at ' + url, flush=True)
    process = subprocess.Popen([str(python), str(ROOT / 'app.py')], cwd=ROOT, env=env)
    try:
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise RuntimeError('The server exited before it was ready. Check the messages above; the port may be occupied.')
            if ready(url):
                print('Ready. Keep this window open while using the app. Press Ctrl+C to stop.', flush=True)
                if not args.no_browser:
                    webbrowser.open(url)
                return process.wait()
            time.sleep(0.25)
        raise RuntimeError('The server did not become ready within 30 seconds.')
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()

if __name__ == '__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print('Consensus Portfolio stopped.')
        sys.exit(0)
    except Exception as exc:
        print('Unable to launch: ' + str(exc), file=sys.stderr)
        sys.exit(1)

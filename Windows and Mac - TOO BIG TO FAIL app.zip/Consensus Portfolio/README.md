# TOO BIG TO FAIL

A local Python portfolio research app with an ultra-dark, sharp-edged glass interface. Its only action is to scan public sources and calculate a model allocation; there is no brokerage connection.

## Run on Windows or macOS

Extract the complete ZIP and keep its files together.

- **Windows:** double-click `Start on Windows.bat`.
- **macOS:** double-click `Consensus Portfolio.app` or `Start on Mac.command`.

Both launchers set up dependencies, start port **8765**, wait for the server to become ready, and open **http://127.0.0.1:8765** in the default browser. Keep the terminal window open. Press Ctrl+C to stop. If the app is already running on that port, the launcher opens the existing instance.

Requires **Python 3.9 or newer**, which is not bundled. On Windows, enable **Add Python to PATH** when installing Python. Dependencies for the original Mac environment and common Windows x64 Python versions are bundled in `wheels/`; incompatible or unavailable wheels are downloaded automatically if internet access is available.

For terminal use on either platform:

```sh
python launch.py
```

Use `python3 launch.py` on macOS if `python` is not available. The shared launcher is `launch.py`; the Windows and Mac wrappers only select Python and invoke it. `python launch.py --port 8766 --no-browser` supports an alternate local port for development.

Internet access is required to scan holdings. The saved allocation and sources can be viewed offline. No credentials or API keys are required. This is a local Flask app, not a public production deployment.

The macOS app wrapper source is `launchers/mac.applescript`. It can be rebuilt on macOS with `osacompile -o "Consensus Portfolio.app" launchers/mac.applescript`.

## Portfolio rules

1. Scan the configured 167 source portfolios. Read their top **two direct holdings** and reported asset values.
2. Divide each source's assets by the sum of all included source assets. Use fund/account net assets, and disclosed 13F securities value for pension filers. These are not company market caps.
3. Each distinct source gives each top-two stock **one vote** and its full source weight. SPY has no special multiplier. Bonds, cash, properties, and underlying funds do not generate stock votes. There is no fund lookthrough.
4. Require **at least three votes** and a verified U.S. exchange listing. Listed ADRs qualify; OTC-only securities do not. Consolidate the configured GOOG/GOOGL and MOG.A/MOG.B share classes into one company vote per source.
5. Sort by weighted score, then company name for ties. Select up to ten. Leave slots empty if fewer than ten qualify.
6. Normalize selected scores to 100%. Largest-remainder rounding makes displayed two-decimal percentages total exactly 100.00%.

For example, three sources containing a stock qualify it even if they are small. Two very large sources do not meet the three-vote cutoff. Each qualifying stock's allocation then reflects contributing capital, not its raw vote count.

## Rebalance and freshness

**Rebalance** starts a background scan and shows progress. The app checks Nasdaq Trader's exchange directories, scans holdings/assets, recalculates the model, and saves a new snapshot. A complete successful scan resets the freshness clock. The UI displays a holdings-scan warning when **more than seven days** pass, including while the page remains open.

If even one source fails, the entire previous allocation and its original successful-scan timestamp remain unchanged. The UI identifies failed sources. Partial results are retained separately for inspection, never silently blended into the model. Concurrent scans are rejected. Opening the app does not trigger a scan.

## Sources and limitations

- [Stock Analysis](https://stockanalysis.com/) supplies the configured ETF/mutual-fund holdings and most displayed fund asset values.
- TIAA issuer factsheets supply CREF account and real-estate account net assets. Their exact PDF links are stored with each record.
- [13f.info](https://13f.info/) supplies pension-filer holdings and disclosed securities totals. The scanner selects the latest quarter and prefers a newer corrected filing; same-day restatements take precedence over originals.
- [Nasdaq Trader symbol directories](https://www.nasdaqtrader.com/trader.aspx?id=symboldirdefs) verify U.S. exchange eligibility and identify ETFs.

The **Sources** tab and JSON export contain exact per-record holdings and asset URLs, reporting dates where available, and source notes. A recent retrieval does not mean the underlying report is recent. Many displayed asset values have no stated valuation date; individual source details identify missing dates. Holdings and asset reports can cover different dates.

Reported assets overlap across funds and accounts; their sum is **not unique capital**. A stock's weighted score is source influence, not dollars invested in that stock: this model deliberately does not multiply by the stock's percentage inside each source. Pension 13Fs are partial disclosures, not whole pension portfolios. The configured universe is not every retirement plan or fund in existence. A 401(k), IRA, or Roth account is not itself a fund.

NYC Employees, NYC Teachers, and Pennsylvania SERS remain excluded pending verified holdings. The fixed source universe does not automatically discover new target-date vintages. Source-page changes or service limits can cause scans to fail visibly.

## Files

- `app.py`: local HTTP API, background scan coordination, atomic persistence.
- `engine.py`: portfolio calculation and seven-day freshness rules.
- `sources.py`: public-source readers, filing correction handling, exchange resolution.
- `static/`: HTML, CSS, and browser JavaScript. Portfolio and scan logic run in Python.
- `data/seed.json`: imported research and source configuration.
- `data/state.json`: last applied allocation inputs and provenance.
- `data/history/`: complete successful scan snapshots, created when scans run.
- `data/last_scan_attempt.json`: created when a scan is incomplete, to retain partial inputs.
- `tests/test_portfolio.py`: calculation, parser, scan persistence, and API regression tests.

No credentials or API keys are needed. New portfolio rules should go in `engine.py`; new data providers should go in `sources.py`.

## Verify

macOS:
```sh
.venv/bin/python -m unittest discover -s tests -v
```

Windows:
```bat
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Browser verification also covers a real 167-source rebalance, allocation totals, source search/filter, source links, methodology, JSON download, mobile layout, and the overdue warning.

"""Read-only public-source adapters. Parse failures never become zero-valued funds."""
import calendar
import io
import re
import urllib.request
from datetime import datetime
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from pypdf import PdfReader

USER_AGENT = 'TooBigToFail/0.1 (personal portfolio research; read-only)'


def fetch(url):
    request = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
    with urllib.request.urlopen(request, timeout=22) as response:
        if response.status != 200:
            raise ValueError(f'Source returned HTTP {response.status}')
        body = response.read(12_000_001)
        if len(body) > 12_000_000:
            raise ValueError('Source exceeds 12 MB limit')
        return body


def soup_for(url):
    soup = BeautifulSoup(fetch(url), 'html.parser')
    for tag in soup(['script', 'style', 'nav', 'footer']):
        tag.decompose()
    return soup


def amount(value):
    match = re.fullmatch(r'\s*\$?([\d,.]+)\s*(T|B|M|K|trillion|billion|million|thousand)?\s*', value, re.I)
    if not match:
        raise ValueError(f'Unrecognized asset value: {value[:70]}')
    units = {'t': 1e12, 'trillion': 1e12, 'b': 1e9, 'billion': 1e9, 'm': 1e6, 'million': 1e6, 'k': 1e3, 'thousand': 1e3, '': 1}
    result = round(float(match[1].replace(',', '')) * units[(match[2] or '').lower()])
    if result <= 0:
        raise ValueError('Asset value must be positive')
    return result


def date_from(text):
    patterns = [r'As of\s+(\w+\s+\d{1,2},\s*20\d{2})', r'As of\s+(\d{1,2}/\d{1,2}/20\d{2})']
    matches = sorted((m for pattern in patterns for m in re.finditer(pattern, text, re.I)), key=lambda m: m.start())
    for match in matches:
        if match:
            for fmt in ('%b %d, %Y', '%B %d, %Y', '%m/%d/%Y'):
                try:
                    return datetime.strptime(match[1], fmt).date().isoformat()
                except ValueError:
                    pass
    return None


def parse_stockanalysis(soup):
    text = soup.get_text(' ', strip=True)
    asset_match = re.search(r'\b(?:Fund )?Assets\s+\$?([\d,.]+\s*[TBMK])\b', text)
    assets = amount(asset_match[1]) if asset_match else None
    holdings = []
    for table in soup.find_all('table'):
        headers = [th.get_text(' ', strip=True) for th in table.find_all('th')]
        if not ('Name' in headers and 'Symbol' in headers):
            continue
        for tr in table.find_all('tr'):
            cells = tr.find_all('td', recursive=False)
            if len(cells) < 3:
                continue
            values = [c.get_text(' ', strip=True) for c in cells]
            if headers[0] == 'No.' and (not values[0].isdigit() or int(values[0]) not in (1, 2)):
                continue
            name_index, symbol_index = headers.index('Name'), headers.index('Symbol')
            if max(name_index, symbol_index) >= len(cells):
                continue
            name, symbol = values[name_index], values[symbol_index]
            links = [a.get('href', '') for c in cells[:3] for a in c.find_all('a')]
            is_fund = any('/etf/' in link or '/mutf/' in link for link in links)
            is_fund = is_fund or bool(re.search(r'\b(?:index fund|idx|etf|money market|institutional plus)\b', name, re.I))
            is_debt = bool(re.search(r'treasury|treasuries|\b(?:note|bond|bonds|tba|unsecured|secured|srunsecured|srsecured|cbt)\b|\d+\.\d+%', name, re.I)) or bool(re.search(r'\d[./]\d', symbol))
            is_stock = not (is_fund or is_debt) and (any('/stocks/' in link or '/quote/' in link for link in links) or symbol not in ('', 'n/a', '—'))
            holdings.append({'name': name, 'symbol': symbol, 'kind': 'fund' if is_fund else ('stock' if is_stock else 'other')})
            if len(holdings) == 2:
                break
        if holdings:
            break
    if len(holdings) != 2:
        raise ValueError('Source did not provide two parseable direct holdings')
    return assets, holdings, date_from(text)


def parse_pdf_assets(body):
    pdf = PdfReader(io.BytesIO(body))
    text = pdf.pages[0].extract_text()
    match = re.search(r'\$\s*([\d,.]+)\s*(Billion|Million)', text, re.I)
    if not match:
        raise ValueError('No account net assets found in issuer factsheet')
    return amount(match[1] + match[2]), date_from(text), pdf


def scan_fund(record):
    soup = soup_for(record['scan_url'])
    assets, holdings, holdings_date = parse_stockanalysis(soup)
    asset_source = record['scan_url']
    asset_date = None
    if record.get('pdf_url'):
        assets, asset_date, _ = parse_pdf_assets(fetch(record['pdf_url']))
        asset_source = record['pdf_url']
    elif not assets:
        overview = record['scan_url'].replace('holdings/', '')
        text = soup_for(overview).get_text(' ', strip=True)
        match = re.search(r'\b(?:Fund )?Assets\s+\$?([\d,.]+\s*[TBMK])\b', text)
        if match:
            assets = amount(match[1])
            asset_source = overview
    if not assets:
        raise ValueError('Fund assets unavailable; previous value not substituted')
    return {**record, 'assets_usd': assets, 'asset_date': asset_date, 'holdings_date': holdings_date,
            'holdings': holdings, 'asset_source': asset_source, 'holdings_source': record['scan_url'],
            'source_note': 'Issuer account net assets.' if record.get('pdf_url') else 'Displayed fund assets; valuation date not stated by source.'}


def parse_holdingschannel(soup):
    text = soup.get_text(' ', strip=True)
    totals = re.findall(r'At\s+(\d{2}/\d{2}/\d{4}):\s*\$([\d,]+)', text)
    if not totals:
        raise ValueError('13F portfolio total not found')
    stamp, total = totals[0]
    holdings, seen = [], set()
    for anchor in soup.select('a[href*="/institutional/holders-of-"]'):
        ticker = anchor['href'].split('holders-of-')[-1].strip('/').upper()
        if ticker in seen:
            continue
        seen.add(ticker)
        holdings.append({'name': anchor.get_text(' ', strip=True), 'symbol': ticker, 'kind': 'stock'})
        if len(holdings) == 2:
            break
    if len(holdings) != 2:
        raise ValueError('13F top two positions not found')
    return int(total.replace(',', '')) * 1000, holdings, datetime.strptime(stamp, '%m/%d/%Y').date().isoformat()


def parse_13f_info(soup):
    candidates = []
    for table in soup.find_all('table'):
        if 'Value ($000)' not in table.get_text(' ', strip=True):
            continue
        for tr in table.find_all('tr'):
            cells = tr.find_all('td')
            if len(cells) < 4:
                continue
            q = re.search(r'Q([1-4])\s+(20\d{2})', cells[0].get_text())
            if not q:
                continue
            month, year = int(q[1]) * 3, int(q[2])
            stamp = f'{year}-{month:02d}-{calendar.monthrange(year, month)[1]}'
            total = int(cells[2].get_text(strip=True).replace(',', '')) * 1000
            symbols = [s.strip() for s in cells[3].get_text(' ', strip=True).split(',')][:2]
            # A correction can appear AFTER its original filing in the table.
            # Pick the latest quarter, then latest filing; same-day restatements win.
            form = cells[4].get_text(strip=True) if len(cells) > 4 else ''
            filed = datetime.strptime(cells[5].get_text(strip=True), '%m/%d/%Y') if len(cells) > 5 else datetime(year, month, 1)
            filing_id = cells[6].get_text(strip=True) if len(cells) > 6 else ''
            candidates.append(((year, month, filed, form == 'RESTATEMENT', filing_id),
                               (total, [{'name': s, 'symbol': s, 'kind': 'stock'} for s in symbols], stamp)))
    if candidates:
        selected = max(candidates, key=lambda item: item[0])[1]
        if len(selected[1]) != 2 or any(not h['symbol'] for h in selected[1]):
            raise ValueError('Latest 13F summary is missing top holdings')
        return selected
    raise ValueError('13F quarter/value table not found')


def scan_pension(record):
    soup = soup_for(record['scan_url'])
    parser = parse_13f_info if '13f.info' in record['scan_url'] else parse_holdingschannel
    assets, holdings, stamp = parser(soup)
    return {**record, 'assets_usd': assets, 'asset_date': stamp, 'holdings_date': stamp,
            'holdings': holdings, 'asset_source': record['scan_url'], 'holdings_source': record['scan_url'],
            'source_note': '13F reported securities only; not full pension assets.'}


def scan_property(record):
    assets, stamp, pdf = parse_pdf_assets(fetch(record['pdf_url']))
    # Property account contributes to the asset denominator but never emits stock votes.
    text = ' '.join(page.extract_text() for page in pdf.pages)
    section = re.split(r'Top\s+10\s+Holdings\d*', text, flags=re.I)
    holdings = []
    if len(section) > 1:
        for name in re.findall(r'([A-Za-z][A-Za-z ,.&()-]+?)\s+[\d.]+%', section[1]):
            name = ' '.join(name.split())
            if name and name not in ('Total',):
                holdings.append({'name': name, 'symbol': '', 'kind': 'property'})
            if len(holdings) == 2:
                break
    if len(holdings) != 2:
        raise ValueError('Property holdings could not be read')
    return {**record, 'assets_usd': assets, 'asset_date': stamp, 'holdings_date': stamp, 'holdings': holdings,
            'asset_source': record['pdf_url'], 'holdings_source': record['pdf_url'],
            'source_note': 'Net account assets; issuer ranking covers properties.'}


def scan_record(record):
    if record['kind'] == 'pension':
        return scan_pension(record)
    if record['kind'] == 'property':
        return scan_property(record)
    return scan_fund(record)


def exchange_directory():
    listings = {}
    for filename in ('nasdaqlisted.txt', 'otherlisted.txt'):
        url = 'https://www.nasdaqtrader.com/dynamic/SymDir/' + filename
        text = fetch(url).decode()
        for line in text.splitlines()[1:]:
            fields = line.split('|')
            if len(fields) < 8 or line.startswith('File Creation'):
                continue
            if filename == 'nasdaqlisted.txt':
                symbol, name, exchange, test, etf = fields[0], fields[1], 'Nasdaq', fields[3], fields[6]
            else:
                symbol, name, code, _, etf, _, test = fields[:7]
                exchange = {'N': 'NYSE', 'A': 'NYSE American', 'P': 'NYSE Arca', 'Z': 'Cboe BZX', 'V': 'IEX'}.get(code)
            if test == 'N' and exchange:
                listings[symbol] = {'ticker': symbol, 'name': name.split(' - ')[0], 'exchange': exchange,
                                    'eligible': etf == 'N', 'is_fund': etf == 'Y', 'source': url}
    if len(listings) < 1000:
        raise ValueError('Exchange directory appears incomplete')
    return listings


def normalize_company(name):
    name = name.lower().replace('&', 'and')
    name = re.sub(r'\b(corporation|corp|incorporated|inc|company|co|limited|ltd|holdings|holding|plc|common|stock|shares|class|registered|registry|ordinary)\b', '', name)
    return re.sub(r'[^a-z0-9]', '', name)


def resolve_holdings(record, directory, aliases):
    listing_updates = {}
    keys = set()
    for holding in record['holdings'][:2]:
        if holding['kind'] not in ('stock',):
            continue
        symbol = holding['symbol'].replace('-', '.')
        alias = aliases.get(normalize_company(holding['name']))
        if symbol not in directory and alias:
            symbol = alias
        # Same-company share classes do not create extra votes.
        symbol = {'GOOG': 'GOOGL', 'MOG.B': 'MOG.A'}.get(symbol, symbol)
        if symbol in directory:
            if directory[symbol].get('is_fund'):
                holding['kind'] = 'fund'
                continue
            key = symbol
            listing_updates[key] = directory[symbol]
        else:
            key = 'foreign:' + normalize_company(holding['name'])
            listing_updates[key] = {'name': holding['name'], 'ticker': holding['symbol'], 'exchange': 'Unlisted / OTC', 'eligible': False}
        keys.add(key)
    record['stock_keys'] = sorted(keys)
    return record, listing_updates

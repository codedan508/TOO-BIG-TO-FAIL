const $ = (id) => document.getElementById(id);
const colors = ['#e2e3dc','#788988','#b5b3a5','#78808b','#b1b8bb','#646d73','#8c9497','#a69c8b','#697a79','#53636b'];
let state, view = 'portfolio', previousJob, polling = false;
const escapeHTML = (s) => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = (n) => n >= 1e12 ? `$${(n/1e12).toFixed(2)}T` : n >= 1e9 ? `$${(n/1e9).toFixed(2)}B` : `$${(n/1e6).toFixed(2)}M`;
const pct = (n) => Number(n).toFixed(2);
const date = (s) => s ? new Date(s.length===10 ? s+'T12:00:00' : s).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'}) : 'Not provided';
const safeLink = (url) => {try {const u=new URL(url);return u.protocol==='https:'?escapeHTML(u.href):'#';}catch{return '#';}};

function changeView(next) {
  view=next;
  for (const key of ['portfolio','sources','method']) $(key+'-view').hidden=key!==view;
  document.querySelectorAll('nav [data-view]').forEach(b=>{b.classList.toggle('active',b.dataset.view===view);if(b.dataset.view===view)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
  if(view==='sources' && state) renderSources();
}
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>changeView(b.dataset.view)));

function render() {
  const p=state.portfolio,j=state.job,running=j.status==='running';
  $('rebalance').disabled=running;
  $('rebalance-label').textContent=running?'Scanning…':'Rebalance';
  document.body.classList.toggle('scanning',running);
  $('nav-count').textContent=p.source_count;
  $('total-assets').textContent=money(p.total_assets_usd);
  $('source-count').textContent=p.source_count;
  $('total-foot').textContent=p.selected.length?'100.00%':'0.00%';
  $('last-scan').textContent=state.last_successful_scan?date(state.last_successful_scan):'Live scan not yet completed';
  $('scan-context').textContent=state.last_successful_scan?`${Math.floor(state.freshness.age_days)} days ago · saved locally`:`Research seeded ${date(state.seed_date)}`;
  $('freshness').hidden=!state.freshness.needs_scan;
  $('freshness-text').textContent=state.freshness.reason==='overdue'?'More than 1 week has passed since the last complete scan. Run a holdings scan to rebalance.':'This allocation uses the saved research snapshot. Run Rebalance for a complete public-source scan.';
  $('allocation-strip').innerHTML=p.selected.map((r,i)=>`<span style="width:${r.allocation_pct}%;--c:${colors[i]}" title="${escapeHTML(r.ticker)} · ${pct(r.allocation_pct)}%"></span>`).join('');
  $('allocation-strip').setAttribute('aria-label',p.selected.map(r=>`${r.ticker} ${pct(r.allocation_pct)} percent`).join(', '));
  $('allocation-body').innerHTML=p.selected.length?p.selected.map((r,i)=>`<tr><td><div class="asset-cell"><span class="asset-dot" style="--c:${colors[i]}"></span><div class="asset-symbol"><strong>${escapeHTML(r.ticker)}</strong><span>${escapeHTML(r.name)}</span></div></div></td><td><span class="votes">${r.votes}</span></td><td class="allocation-value">${pct(r.allocation_pct)}<small>%</small></td><td><button class="row-arrow" data-stock="${escapeHTML(r.key)}" aria-label="Inspect ${escapeHTML(r.name)} contributors">↗</button></td></tr>`).join(''):'<tr><td class="empty" colspan="4">No stocks meet the three-vote and U.S. listing requirements.</td></tr>';
  $('scan-progress').hidden=j.status==='idle';
  if(j.status!=='idle') {
    $('scan-phase').textContent=j.phase;
    $('scan-numbers').textContent=`${j.completed} / ${j.total}`;
    $('scan-fill').style.width=`${j.total?j.completed/j.total*100:0}%`;
    $('scan-detail').textContent=running?(j.current?`Checked ${j.current}`:'Reading the exchange directories…'):j.status==='complete'?`${j.updated} source portfolios refreshed. The allocation is saved.`:`${j.updated} sources refreshed; ${j.failures.length} failed. The previous snapshot and scan date are retained.`;
    $('review-scan').hidden=!j.failures.length;
  } else if(state.last_attempt?.failures?.length) {
    $('scan-progress').hidden=false;
    $('scan-phase').textContent='Previous scan incomplete · saved allocation retained';
    $('scan-numbers').textContent=`${state.last_attempt.updated} / ${state.last_attempt.total}`;
    $('scan-detail').textContent=`${state.last_attempt.failures.length} sources could not be refreshed. Retry with Rebalance.`;
    $('review-scan').hidden=false;
  }
  if(previousJob==='running' && j.status==='complete')toast('Scan complete. Your model allocation has been updated.');
  previousJob=j.status;
  if(view==='sources')renderSources();
}

function renderSources() {
  const query=$('source-search').value.toLowerCase().trim(),type=$('source-type').value;
  const rows=state.records.filter(r=>(type==='all'||r.kind===type)&&`${r.id} ${r.name} ${r.holdings.map(h=>h.name).join(' ')}`.toLowerCase().includes(query)).sort((a,b)=>b.assets_usd-a.assets_usd);
  $('source-result-count').textContent=`${rows.length} / ${state.records.length} ENTRIES`;
  $('source-body').innerHTML=rows.length?rows.map(r=>`<tr><td><span class="source-id">${escapeHTML(r.id)}</span>${r.name!==r.id?`<span class="source-name">${escapeHTML(r.name)}</span>`:''}</td><td>${money(r.assets_usd)}</td><td>${state.portfolio.fund_weights[r.id].toFixed(3)}%</td><td>${r.holdings.map(h=>escapeHTML(h.name)).join('<br>')}</td><td>${date(r.asset_date)}</td><td><button class="row-arrow" data-source="${escapeHTML(r.id)}" aria-label="Inspect source ${escapeHTML(r.id)}">↗</button></td></tr>`).join(''):'<tr><td colspan="6" class="empty">No sources match your search.</td></tr>';
  $('source-disclaimer').textContent=`Pension figures represent 13F-disclosed securities, not the entire retirement system. Fund-of-fund assets can overlap. Source reports use different dates. Excluded pending verified holdings: ${state.excluded_sources.join('; ')}.`;
}

function openDialog(title,eyebrow,html){$('dialog-title').textContent=title;$('dialog-eyebrow').textContent=eyebrow;$('dialog-content').innerHTML=html;$('detail-dialog').showModal();}
$('close-dialog').addEventListener('click',()=>$('detail-dialog').close());
$('detail-dialog').addEventListener('click',e=>{if(e.target===$('detail-dialog')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.target.close();}});
document.addEventListener('click',e=>{
  const stockButton=e.target.closest('[data-stock]'),sourceButton=e.target.closest('[data-source]');
  if(stockButton){const r=state.portfolio.ranked.find(x=>x.key===stockButton.dataset.stock);openDialog(r.name,`${r.ticker} / ${r.exchange}`,`<p>${r.votes} distinct source votes contribute a ${pct(r.score_pct)}% weighted score. That score is normalized with the other selected stocks to determine allocation.</p>`+r.contributors.map(id=>{const f=state.records.find(x=>x.id===id);return `<div class="detail-row"><a href="${safeLink(f.holdings_source)}" target="_blank" rel="noopener noreferrer">${escapeHTML(id)} ↗<small>${escapeHTML(f.holdings_date?date(f.holdings_date):'Holdings date not recorded')}</small></a><span>${state.portfolio.fund_weights[id].toFixed(3)}%<small>${money(f.assets_usd)} reported assets</small></span></div>`;}).join(''));}
  if(sourceButton){const r=state.records.find(x=>x.id===sourceButton.dataset.source);openDialog(r.id,'SOURCE PORTFOLIO',`<p>${escapeHTML(r.name)}</p><div class="detail-row"><span>Reported assets</span><span>${money(r.assets_usd)}</span></div><div class="detail-row"><span>Weight in model</span><span>${state.portfolio.fund_weights[r.id].toFixed(4)}%</span></div><div class="detail-row"><span>Asset valuation date</span><span>${date(r.asset_date)}</span></div><div class="detail-row"><span>Holdings report date</span><span>${date(r.holdings_date)}</span></div><p>${escapeHTML(r.source_note)}</p><div class="detail-row"><span>Holdings</span><a href="${safeLink(r.holdings_source)}" target="_blank" rel="noopener noreferrer">Read holdings source ↗</a></div><div class="detail-row"><span>Assets</span><a href="${safeLink(r.asset_source)}" target="_blank" rel="noopener noreferrer">Read asset source ↗</a></div>`);}
});
$('source-search').addEventListener('input',renderSources);$('source-type').addEventListener('change',renderSources);
$('review-scan').addEventListener('click',()=>{const failures=state.job.failures.length?state.job.failures:state.last_attempt?.failures||[];openDialog('A scan with gaps.','PREVIOUS ALLOCATION RETAINED','<p>Every included source must return usable data before a new snapshot is applied. These errors did not reset the weekly scan clock.</p>'+failures.map(f=>`<div class="detail-row"><span>${escapeHTML(f.id)}<small>${escapeHTML(f.message)}</small></span>${f.url?`<a href="${safeLink(f.url)}" target="_blank" rel="noopener noreferrer">Source ↗</a>`:''}</div>`).join(''));});
function toast(message){$('toast').textContent=message;$('toast').hidden=false;setTimeout(()=>$('toast').hidden=true,5500);}
async function refresh(){if(polling)return;polling=true;try{const response=await fetch('/api/state');if(!response.ok)throw Error('State unavailable');state=await response.json();$('connection-error').hidden=true;render();}catch(e){$('connection-error').hidden=false;$('rebalance').disabled=true;}finally{polling=false;}}
$('rebalance').addEventListener('click',async()=>{$('rebalance').disabled=true;try{const response=await fetch('/api/rebalance',{method:'POST'});if(!response.ok){const error=await response.json();throw Error(error.error||'Could not start scan');}await refresh();}catch(e){toast(e.message);$('rebalance').disabled=false;}});
refresh();setInterval(()=>{if(state?.job.status==='running')refresh();},1500);setInterval(refresh,60000);

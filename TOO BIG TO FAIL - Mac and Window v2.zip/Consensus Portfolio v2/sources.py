"""Read-only public-source adapters. Parse failures never become zero-valued funds."""
import calendar
import hashlib
import copy
import threading
from concurrent.futures import Future
import io
import json
import re
import urllib.request
from datetime import datetime, timezone
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from pypdf import PdfReader

USER_AGENT = 'TooBigToFail/0.1 (personal portfolio research; read-only)'


def fetch(url):
    request = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
    with urllib.request.urlopen(request, timeout=22) as response:
        if response.status != 200:
            raise ValueError(f'Source returned HTTP {response.status}')
        body = response.read(12_000_001)
        if len(body) > 12_000_000:
            raise ValueError('Source exceeds 12 MB limit')
        return body


def soup_for(url):
    soup = BeautifulSoup(fetch(url), 'html.parser')
    for tag in soup(['script', 'style', 'nav', 'footer']):
        tag.decompose()
    return soup


def amount(value):
    match = re.fullmatch(r'\s*\$?([\d,.]+)\s*(T|B|M|K|trillion|billion|million|thousand)?\s*', value, re.I)
    if not match:
        raise ValueError(f'Unrecognized asset value: {value[:70]}')
    units = {'t': 1e12, 'trillion': 1e12, 'b': 1e9, 'billion': 1e9, 'm': 1e6, 'million': 1e6, 'k': 1e3, 'thousand': 1e3, '': 1}
    result = round(float(match[1].replace(',', '')) * units[(match[2] or '').lower()])
    if result <= 0:
        raise ValueError('Asset value must be positive')
    return result


def scan_market_cap(ticker):
    """Fresh company-wide USD cap, including ADR/share-class provider treatment."""
    if not re.fullmatch(r'[A-Z][A-Z0-9.-]*', ticker):
        raise ValueError('Invalid market-cap ticker')
    url = f'https://stockanalysis.com/stocks/{ticker.lower()}/market-cap/'
    body = fetch(url)
    return parse_market_cap(BeautifulSoup(body, 'html.parser'), ticker, url, body)


def parse_market_cap(soup, ticker, url, body=b''):
    main = soup.find('main')
    if main is None:
        raise ValueError(f'{ticker}: company market-cap page unavailable')
    text = main.get_text(' ', strip=True)
    if not re.search(r'\(' + re.escape(ticker) + r'\)\s+(?:NASDAQ|NYSE|NYSEAMERICAN|NYSEARCA|NYSE American|NYSE Arca|CBOE|BATS):', text, re.I):
        raise ValueError(f'{ticker}: market-cap page security identity mismatch')
    if not re.search(r'\bUSD\b', text[:350]):
        raise ValueError(f'{ticker}: company market-cap currency is not verified USD')
    match = re.search(r'has a market cap or net worth of \$([\d,.]+) (trillion|billion|million) as of ([A-Za-z]+ \d{1,2}, \d{4})', text)
    if not match:
        raise ValueError(f'{ticker}: dated company market cap unavailable; no old value substituted')
    stamp = datetime.strptime(match[3], '%B %d, %Y').date()
    now = datetime.now(timezone.utc)
    if not 0 <= (now.date() - stamp).days <= 7:
        raise ValueError(f'{ticker}: market-cap valuation date {stamp} is stale or in the future')
    return {'ticker': ticker, 'currency': 'USD', 'market_cap_usd': amount(match[1] + match[2]),
            'market_cap_date': stamp.isoformat(), 'retrieved_at': now.isoformat(), 'url': url,
            'sha256': hashlib.sha256(body).hexdigest(),
            'scope': 'Provider-reported company market cap in USD; not fund assets or ADR price times ordinary shares.'}


def date_from(text):
    patterns = [r'As of\s+(\w+\s+\d{1,2},\s*20\d{2})', r'As of\s+(\d{1,2}/\d{1,2}/20\d{2})']
    matches = sorted((m for pattern in patterns for m in re.finditer(pattern, text, re.I)), key=lambda m: m.start())
    for match in matches:
        if match:
            for fmt in ('%b %d, %Y', '%B %d, %Y', '%m/%d/%Y'):
                try:
                    return datetime.strptime(match[1], fmt).date().isoformat()
                except ValueError:
                    pass
    return None


def parse_stockanalysis(soup):
    text = soup.get_text(' ', strip=True)
    asset_match = re.search(r'\b(?:Fund )?Assets\s+\$?([\d,.]+\s*[TBMK])\b', text)
    assets = amount(asset_match[1]) if asset_match else None
    holdings = []
    for table in soup.find_all('table'):
        headers = [th.get_text(' ', strip=True) for th in table.find_all('th')]
        if not ('Name' in headers and 'Symbol' in headers):
            continue
        for tr in table.find_all('tr'):
            cells = tr.find_all('td', recursive=False)
            if len(cells) < 3:
                continue
            values = [c.get_text(' ', strip=True) for c in cells]
            if headers[0] == 'No.' and (not values[0].isdigit() or int(values[0]) not in (1, 2)):
                continue
            name_index, symbol_index = headers.index('Name'), headers.index('Symbol')
            if max(name_index, symbol_index) >= len(cells):
                continue
            name, symbol = values[name_index], values[symbol_index]
            links = [a.get('href', '') for c in cells[:3] for a in c.find_all('a')]
            is_fund = any('/etf/' in link or '/mutf/' in link for link in links)
            is_fund = is_fund or bool(re.search(r'\b(?:fund|idx|etf|money market|institutional plus)\b', name, re.I))
            is_debt = bool(re.search(r'treasury|treasuries|\b(?:note|bond|bonds|tba|unsecured|secured|srunsecured|srsecured|cbt)\b|\d+\.\d+%', name, re.I)) or bool(re.search(r'\d[./]\d', symbol))
            is_stock = not (is_fund or is_debt) and (any('/stocks/' in link or '/quote/' in link for link in links) or symbol not in ('', 'n/a', '—'))
            holding = {'name': name, 'symbol': symbol, 'kind': 'fund' if is_fund else ('stock' if is_stock else 'other')}
            holding['rank'] = int(values[0]) if headers[0] == 'No.' else len(holdings) + 1
            weight_header = next((h for h in headers if h.strip('% ').lower() == 'weight'), None)
            if weight_header:
                holding['weight_pct'] = float(values[headers.index(weight_header)].rstrip('%').replace(',', ''))
            fund_link = next((link for link in links if '/etf/' in link or '/mutf/' in link), None)
            if fund_link:
                holding['fund_url'] = urljoin('https://stockanalysis.com', fund_link).rstrip('/') + '/holdings/'
            holdings.append(holding)
            if len(holdings) == 2:
                break
        if holdings:
            break
    if len(holdings) != 2:
        raise ValueError('Source did not provide two parseable direct holdings')
    return assets, holdings, date_from(text)


def parse_pdf_assets(body):
    pdf = PdfReader(io.BytesIO(body))
    text = pdf.pages[0].extract_text()
    match = re.search(r'\$\s*([\d,.]+)\s*(Billion|Million)', text, re.I)
    if not match:
        raise ValueError('No account net assets found in issuer factsheet')
    return amount(match[1] + match[2]), date_from(text), pdf


def scan_fund(record):
    soup = soup_for(record['scan_url'])
    assets, holdings, holdings_date = parse_stockanalysis(soup)
    asset_source = record['scan_url']
    asset_date = None
    if record.get('pdf_url'):
        assets, asset_date, _ = parse_pdf_assets(fetch(record['pdf_url']))
        asset_source = record['pdf_url']
    elif not assets:
        overview = record['scan_url'].replace('holdings/', '')
        text = soup_for(overview).get_text(' ', strip=True)
        match = re.search(r'\b(?:Fund )?Assets\s+\$?([\d,.]+\s*[TBMK])\b', text)
        if match:
            assets = amount(match[1])
            asset_source = overview
    if not assets:
        raise ValueError('Fund assets unavailable; previous value not substituted')
    return {**record, 'assets_usd': assets, 'asset_date': asset_date, 'holdings_date': holdings_date,
            'holdings': holdings, 'asset_source': asset_source, 'holdings_source': record['scan_url'],
            'source_note': 'Issuer account net assets.' if record.get('pdf_url') else 'Displayed fund assets; valuation date not stated by source.'}


def parse_holdingschannel(soup):
    text = soup.get_text(' ', strip=True)
    totals = re.findall(r'At\s+(\d{2}/\d{2}/\d{4}):\s*\$([\d,]+)', text)
    if not totals:
        raise ValueError('13F portfolio total not found')
    stamp, total = totals[0]
    holdings, seen = [], set()
    for anchor in soup.select('a[href*="/institutional/holders-of-"]'):
        ticker = anchor['href'].split('holders-of-')[-1].strip('/').upper()
        if ticker in seen:
            continue
        seen.add(ticker)
        holdings.append({'name': anchor.get_text(' ', strip=True), 'symbol': ticker, 'kind': 'stock'})
        if len(holdings) == 2:
            break
    if len(holdings) != 2:
        raise ValueError('13F top two positions not found')
    return int(total.replace(',', '')) * 1000, holdings, datetime.strptime(stamp, '%m/%d/%Y').date().isoformat()


def parse_13f_info(soup):
    candidates = []
    for table in soup.find_all('table'):
        if 'Value ($000)' not in table.get_text(' ', strip=True):
            continue
        for tr in table.find_all('tr'):
            cells = tr.find_all('td')
            if len(cells) < 4:
                continue
            q = re.search(r'Q([1-4])\s+(20\d{2})', cells[0].get_text())
            if not q:
                continue
            month, year = int(q[1]) * 3, int(q[2])
            stamp = f'{year}-{month:02d}-{calendar.monthrange(year, month)[1]}'
            total = int(cells[2].get_text(strip=True).replace(',', '')) * 1000
            symbols = [s.strip() for s in cells[3].get_text(' ', strip=True).split(',')][:2]
            # A correction can appear AFTER its original filing in the table.
            # Pick the latest quarter, then latest filing; same-day restatements win.
            form = cells[4].get_text(strip=True) if len(cells) > 4 else ''
            filed = datetime.strptime(cells[5].get_text(strip=True), '%m/%d/%Y') if len(cells) > 5 else datetime(year, month, 1)
            filing_id = cells[6].get_text(strip=True) if len(cells) > 6 else ''
            candidates.append(((year, month, filed, form == 'RESTATEMENT', filing_id),
                               (total, [{'name': s, 'symbol': s, 'kind': 'stock'} for s in symbols], stamp)))
    if candidates:
        selected = max(candidates, key=lambda item: item[0])[1]
        if len(selected[1]) != 2 or any(not h['symbol'] for h in selected[1]):
            raise ValueError('Latest 13F summary is missing top holdings')
        return selected
    raise ValueError('13F quarter/value table not found')


def scan_pension(record):
    soup = soup_for(record['scan_url'])
    parser = parse_13f_info if '13f.info' in record['scan_url'] else parse_holdingschannel
    assets, holdings, stamp = parser(soup)
    return {**record, 'assets_usd': assets, 'asset_date': stamp, 'holdings_date': stamp,
            'holdings': holdings, 'asset_source': record['scan_url'], 'holdings_source': record['scan_url'],
            'source_note': '13F reported securities only; not full pension assets.'}


def scan_property(record):
    assets, stamp, pdf = parse_pdf_assets(fetch(record['pdf_url']))
    # Property account contributes to the asset denominator but never emits stock votes.
    text = ' '.join(page.extract_text() for page in pdf.pages)
    section = re.split(r'Top\s+10\s+Holdings\d*', text, flags=re.I)
    holdings = []
    if len(section) > 1:
        for name in re.findall(r'([A-Za-z][A-Za-z ,.&()-]+?)\s+[\d.]+%', section[1]):
            name = ' '.join(name.split())
            if name and name not in ('Total',):
                holdings.append({'name': name, 'symbol': '', 'kind': 'property'})
            if len(holdings) == 2:
                break
    if len(holdings) != 2:
        raise ValueError('Property holdings could not be read')
    return {**record, 'assets_usd': assets, 'asset_date': stamp, 'holdings_date': stamp, 'holdings': holdings,
            'asset_source': record['pdf_url'], 'holdings_source': record['pdf_url'],
            'source_note': 'Net account assets; issuer ranking covers properties.'}


def scan_record(record):
    if record['kind'] == 'pension':
        return scan_pension(record)
    if record['kind'] == 'property':
        return scan_property(record)
    return scan_fund(record)


def exchange_directory():
    listings = {}
    for filename in ('nasdaqlisted.txt', 'otherlisted.txt'):
        url = 'https://www.nasdaqtrader.com/dynamic/SymDir/' + filename
        text = fetch(url).decode()
        for line in text.splitlines()[1:]:
            fields = line.split('|')
            if len(fields) < 8 or line.startswith('File Creation'):
                continue
            if filename == 'nasdaqlisted.txt':
                symbol, name, exchange, test, etf = fields[0], fields[1], 'Nasdaq', fields[3], fields[6]
            else:
                symbol, name, code, _, etf, _, test = fields[:7]
                exchange = {'N': 'NYSE', 'A': 'NYSE American', 'P': 'NYSE Arca', 'Z': 'Cboe BZX', 'V': 'IEX'}.get(code)
            if test == 'N' and exchange:
                listings[symbol] = {'ticker': symbol, 'name': name.split(' - ')[0], 'exchange': exchange,
                                    'eligible': etf == 'N', 'is_fund': etf == 'Y', 'source': url}
    if len(listings) < 1000:
        raise ValueError('Exchange directory appears incomplete')
    return listings


def normalize_company(name):
    name = name.lower().replace('&', 'and')
    name = re.sub(r'\b(corporation|corp|incorporated|inc|company|co|limited|ltd|holdings|holding|plc|common|stock|shares|class|registered|registry|ordinary)\b', '', name)
    return re.sub(r'[^a-z0-9]', '', name)


# Identity aliases only: never substitute a similar index fund for an unlisted fund.
FUND_ALIASES = {
    'fidelity series bond index': 'FIFZX',
    'fidelity concord street trust - fidelity series total market index fund': 'FCFMX',
    'ssi us gov money market class': 'GVMXX',
    'ssi us gov money market class state street inst us gov': 'GVMXX',
    'ssc government mm gvmxx': 'GVMXX',
}
SPECIAL_FUNDS = {
    'mktliq 12/31/2049': 'https://personal1.vanguard.com/funds/reports/h308q1.pdf',
    'BIGBX': 'https://www.schwab.wallst.com/Prospect/Research/mutualfunds/portfolio.asp?symbol=BIGBX',
    'GVMXX': 'https://www.ssga.com/us/en/institutional/cash/state-street-institutional-us-government-money-market-fund-premier-class-gvmxx',
    'capital group central cash fund': 'https://www.capitalgroup.com/individual/investments/mutual-funds/details/ccf-m',
    'fidelity revere street trust - fidelity cash central fund': 'https://fundresearch.fidelity.com/mutual-funds/summary/31635A105',
    'fidelity cash central fund': 'https://fundresearch.fidelity.com/mutual-funds/summary/31635A105',
}
LOOKTHROUGH_VERSION = 2


def non_stock_reason(holding):
    """An absent ticker is not evidence that a security is non-equity."""
    name, symbol = holding['name'], holding.get('symbol', '')
    if holding['kind'] == 'property':
        return 'Direct property holding, not a stock.'
    if re.search(r'\b(repo|repurchase)\b', name, re.I):
        return 'Repurchase agreement, not the counterparty bank’s stock.'
    if re.search(r'\b(cbt|xcbt|xcme|e-mini|future|futures)\b', name, re.I):
        return 'Exchange-traded futures contract, not a stock.'
    if re.search(r'treasur|\b(note|notes|bond|bonds|tba|secured|unsecured|srunsecured|srsecured|governm)\b|\d+\.\d+%', name, re.I) or re.search(r'\d[./]\d', symbol):
        return 'Debt security, not the issuer’s stock.'
    if name.lower() in ('cash', 'us dollar', 'aud spot cc'):
        return 'Cash or spot currency balance, not a stock.'
    return None


class HoldingResolutionError(ValueError):
    def __init__(self, errors, record):
        super().__init__('; '.join(errors))
        self.record = record


class HoldingResolver:
    """One fresh cache per scan. Share fetches, never reuse prior-scan holdings."""
    def __init__(self, directory, aliases, loader=None):
        self.directory, self.aliases = directory, aliases
        self.loader = loader or self.load_fund
        self.cache, self.lock = {}, threading.Lock()

    def cached(self, url):
        with self.lock:
            owner = url not in self.cache
            future = self.cache.setdefault(url, Future())
        if owner:
            try:
                future.set_result(self.loader(url))
            except Exception as exc:
                future.set_exception(exc)
        return copy.deepcopy(future.result())

    def load_fund(self, url):
        if url == SPECIAL_FUNDS['mktliq 12/31/2049']:
            pdf = PdfReader(io.BytesIO(fetch(url)))
            text = ' '.join(page.extract_text() for page in pdf.pages)
            compact = re.sub(r'\s+', '', text).lower()
            if not re.search(r'moneymarketfund.{0,100}vanguardmarketliquidityfund', compact):
                raise ValueError('Vanguard Market Liquidity money-market classification unavailable')
            return {'terminal_reason': 'Vanguard classifies Market Liquidity Fund as a money-market fund. Mktliq is the abbreviated holding name.',
                    'holdings_source': url, 'holdings_date': date_from(text),
                    'identity_source': 'https://www.fool.com/coverage/etfs/2026/02/03/which-is-the-better-vanguard-bond-etf/',
                    'retrieved_at': datetime.now().astimezone().isoformat()}
        if '31635A105' in url:
            # The issuer serves fund classification in embedded JSON before rendering.
            raw = fetch(url).decode()
            match = re.search(r'window\.appConfig\s*=\s*(\{.*?\});', raw, re.S)
            info = json.loads(match[1])['fundInformation'] if match else {}
            if info.get('cusip') != '31635A105' or info.get('mstarAssetClass', {}).get('code') != 'MM':
                raise ValueError('Fidelity cash-fund classification not verified')
            return {'terminal_reason': 'Issuer identifies this as a money-market cash investment, not an equity fund.',
                    'holdings_source': url, 'holdings_date': None, 'retrieved_at': datetime.now().astimezone().isoformat()}
        soup = soup_for(url)
        text = soup.get_text(' ', strip=True)
        if url == SPECIAL_FUNDS['BIGBX']:
            section = text[text.find('Top 10 Holdings as of'):]
            rows = re.findall(r'-- (United States Treasury Notes) ([\d.]+)%', section)
            stamp = date_from(section)
            if len(rows) < 2 or not stamp:
                raise ValueError('BIGBX ranked underlying holdings unavailable')
            holdings = [{'name': n, 'symbol': '', 'kind': 'other', 'weight_pct': float(w)} for n,w in rows[:2]]
        elif url == SPECIAL_FUNDS['GVMXX']:
            table = next((t for t in soup.find_all('table') if 'Name Weight' in t.get_text(' ', strip=True) and 'Repo' in t.get_text()), None)
            if table is None:
                raise ValueError('State Street ranked holdings unavailable')
            holdings = []
            for row in table.find_all('tr'):
                cells = row.find_all('td')
                if len(cells) >= 2:
                    holdings.append({'name': cells[0].get_text(' ', strip=True), 'symbol': '', 'kind': 'other',
                                     'weight_pct': float(cells[1].get_text(strip=True).rstrip('%'))})
            holdings = holdings[:2]
            stamp = date_from(text[text.find('Fund Top Holdings'):])
            if len(holdings) != 2:
                raise ValueError('State Street top two missing')
        elif url == SPECIAL_FUNDS['capital group central cash fund']:
            if 'CMQXX' not in text or 'cash reserves' not in text.lower():
                raise ValueError('Capital Group cash-fund classification not verified')
            return {'terminal_reason': 'Issuer identifies the fund as investing cash reserves in short-term debt, not equities.',
                    'holdings_source': url, 'holdings_date': None, 'retrieved_at': datetime.now().astimezone().isoformat()}
        else:
            _, holdings, stamp = parse_stockanalysis(soup)
        return {'holdings': holdings, 'holdings_source': url, 'holdings_date': stamp,
                'retrieved_at': datetime.now().astimezone().isoformat()}

    def resolve(self, record):
        record = copy.deepcopy(record)
        updates, keys, errors = {}, set(), []
        def walk(holding, source, stamp, path):
            node = {**holding, 'source': source, 'report_date': stamp}
            symbol = holding.get('symbol', '').replace('-', '.')
            name = holding['name']
            identity = FUND_ALIASES.get(name.lower())
            if identity:
                symbol = identity
                node['identity_symbol'] = symbol
            is_fund = (holding['kind'] == 'fund' or identity or name.lower() in SPECIAL_FUNDS or
                       self.directory.get(symbol, {}).get('is_fund') or
                       re.search(r'\b(fund|idx|etf|money market)\b', name, re.I))
            if is_fund:
                node['kind'] = 'fund'
                url = SPECIAL_FUNDS.get(symbol) or SPECIAL_FUNDS.get(name.lower()) or holding.get('fund_url')
                if not url:
                    if not re.fullmatch(r'[A-Z]{1,6}', symbol):
                        raise ValueError(f"Unresolved underlying fund: {name}; no verified holdings URL")
                    route = 'quote/mutf/' if len(symbol) == 5 and symbol.endswith('X') else 'etf/'
                    url = 'https://stockanalysis.com/' + route + symbol + '/holdings/'
                if url in path or len(path) >= 10:
                    raise ValueError(f"Underlying fund cycle/depth limit: {name} ({url})")
                try:
                    child = self.cached(url)
                    if child.get('terminal_reason'):
                        node.update(resolution='verified_non_equity_fund', reason=child['terminal_reason'],
                                    holdings_source=child['holdings_source'], holdings_date=child['holdings_date'],
                                    retrieved_at=child.get('retrieved_at'))
                        if child.get('identity_source'):
                            node['identity_source'] = child['identity_source']
                        return node
                    if len(child['holdings']) != 2:
                        raise ValueError('Expected two ranked holdings')
                    node.update(holdings_source=child['holdings_source'], holdings_date=child['holdings_date'],
                                retrieved_at=child.get('retrieved_at'))
                    error_count = len(errors)
                    node['children'] = [checked(h, child['holdings_source'], child['holdings_date'], path + (url,))
                                        for h in child['holdings']]
                    node['resolution'] = 'looked_through' if len(errors) == error_count else 'incomplete'
                except Exception as exc:
                    raise ValueError(f"{name} -> {exc}") from exc
            elif holding['kind'] != 'stock':
                reason = non_stock_reason(holding)
                if not reason:
                    raise ValueError(f'Unclassified holding: {name}; missing ticker is not proof of a non-stock asset')
                node['resolution'] = 'non_stock'
                node['reason'] = reason
            else:
                alias = self.aliases.get(normalize_company(name))
                if symbol not in self.directory and alias:
                    symbol = alias
                symbol = {'GOOG': 'GOOGL', 'MOG.B': 'MOG.A'}.get(symbol, symbol)
                if symbol in self.directory:
                    key = symbol
                    updates[key] = self.directory[symbol]
                else:
                    key = 'foreign:' + normalize_company(name)
                    updates[key] = {'name': name, 'ticker': holding['symbol'], 'exchange': 'Unlisted / OTC', 'eligible': False}
                keys.add(key)
                node.update(stock_key=key, resolution='eligible_stock' if updates[key]['eligible'] else 'ineligible_stock')
            return node
        def checked(holding, source, stamp, path):
            try:
                return walk(holding, source, stamp, path)
            except ValueError as exc:
                errors.append(str(exc))
                return {**holding, 'source': source, 'report_date': stamp, 'resolution': 'unresolved', 'reason': str(exc)}
        record['lookthrough'] = [checked(h, record.get('holdings_source', record['scan_url']), record.get('holdings_date'), ())
                                 for h in record['holdings'][:2]]
        record['stock_keys'] = sorted(keys)
        record['lookthrough_version'] = LOOKTHROUGH_VERSION
        record['lookthrough_status'] = 'incomplete' if errors else 'complete'
        if errors:
            raise HoldingResolutionError(errors, record)
        return record, updates


def resolve_holdings(record, directory, aliases, resolver=None):
    return (resolver or HoldingResolver(directory, aliases)).resolve(record)

#!/bin/zsh
cd "${0:A:h}" || exit 1
for candidate in "$(command -v python3)" /opt/homebrew/bin/python3 /usr/local/bin/python3 /usr/bin/python3; do
  if [[ -x "$candidate" ]] && "$candidate" -c 'import sys; sys.exit(sys.version_info < (3, 9))' 2>/dev/null; then
    "$candidate" launch.py
    app_result=$?
    if (( app_result != 0 )); then
      read "reply?Press Return to close. "
    fi
    exit "$app_result"
  fi
done
print "Python 3.9 or newer is required. Install it from https://www.python.org/downloads/ and try again."
read "reply?Press Return to close. "
exit 1

CONSENSUS PORTFOLIO — HOW THE APP WORKS
Updated September 13, 2026

THE IDEA
Find stocks that appear in several large funds and retirement portfolios.
Then adjust their weights for company size, with no stock above 15% when
a new target allocation is calculated.

WHAT HAPPENS WHEN YOU CLICK REBALANCE

1. Read the sources.
The app checks its saved list of funds, ETFs and retirement portfolios.
It looks up each source's total assets and its two largest holdings.
LIRPX stays excluded, as requested.

2. Look inside funds that own other funds.
If one of those holdings is another fund, look up that fund's top two
holdings too. Keep following the chain until reaching individual stocks
or clearly identified non-stock investments. Bonds, cash and property
do not get stock votes. An unknown holding is an error, not zero votes.

3. Give each source a weight.
Add the reported assets of all included sources. Divide each source's
assets by that total. A source with 10% of the total gets 10% influence.
Do not add the assets of the funds found inside it a second time.
For pension disclosures, use the reported securities value.

4. Count votes and add influence.
Each original source can give a company one vote and its full influence.
Finding the same company twice inside one source still counts once.
SPY gets no special bonus. Matching share classes count as one company.

5. Pick the stocks.
A company must have at least three source votes and trade on a U.S.
stock exchange. U.S.-listed ADRs qualify; OTC-only stocks do not.
Rank qualifying companies by their total source influence. Take up to
ten. For ties, use company name, then company key.
This selection happens BEFORE the company-size adjustment.

6. Work out the starting percentages.
Divide each selected stock's influence by the selected stocks' combined
influence. The starting percentages add to 100%. Round them to two
decimal places while keeping the total at 100%, just like the original
app and the approved experiment.

7. Look up each selected company's market cap.
Market cap means the company's stock-market value. It is different from
a fund's total assets and different from the price of one share.
Use the provider's company market cap in U.S. dollars, including its
company-level treatment of ADRs and share classes. Save the source link,
valuation date and retrieval time. Never multiply an ADR price by an
unadjusted ordinary-share count.

8. Adjust the starting percentages for company size.
For each stock:
    ratio = starting percentage / company market cap
Then divide each ratio by the sum of all the ratios to get new weights.
Example: if two stocks both start at 10%, but one company is ten times
smaller, the smaller company's ratio is ten times larger.
This does not automatically make the smaller company a better investment;
it is simply the weighting rule we chose.

9. Limit each stock to 15% and share the extra.
If a stock would get 25%, give it 15% instead. That leaves 10 percentage
points to share among stocks still below the limit, in proportion to
their ratios. If this pushes another stock over 15%, repeat the process.
Keep going until every stock is at or below 15%.

At least seven stocks are needed to fill 100% under a 15% limit.
If only six qualify, each can receive at most 15%, leaving 10% cash.
Show that leftover as unallocated cash; never break the cap to fill space.
Final rounding keeps stocks plus cash at exactly 100.00%.

10. Save the result only when the whole process works.
Every required holdings, asset, listing and market-cap lookup must work.
If any fails, keep the previous allocation and its original scan date.
Show the failed lookup so the user knows the old result is still shown.
Do not quietly mix old market caps or holdings into a new scan.
Market-cap pages must identify the right security, USD, and a valuation
date no more than seven days old. Source holdings reports may be older;
their individual reporting dates remain visible.

WHEN DOES IT CHANGE?
Only clicking Rebalance starts a fresh full scan and updates the targets.
Opening or refreshing the page just displays the saved result.
After more than one week without a complete successful scan, the app
shows a reminder. The reminder does not rebalance anything by itself.

There is NO daily rebalancing and NO automatic buying or selling.
The app is a model, not a brokerage account. If someone buys the stocks
and holds them, changing prices can move their real weights above 15%.
The 15% limit applies when the app calculates a new target allocation.

WHERE TO CHECK THE NUMBERS
The Sources tab shows fund holdings, assets, votes and source links.
Click a stock's arrow to see its original percentage, company market cap,
market-cap source/date and final target. Export allocation saves the
rules, inputs, market caps and results together as JSON.

A LIMIT TO REMEMBER
Funds can own overlapping investments. Combined source assets are not
unique dollars. We use these numbers to measure source influence, not
to claim that this exact amount of money is invested in each stock.
Past backtest performance is not a step in the app's calculation.

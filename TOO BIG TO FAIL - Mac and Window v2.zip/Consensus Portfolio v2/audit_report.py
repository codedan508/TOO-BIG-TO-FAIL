"""One audited source snapshot for text reports and downstream research exports."""
from collections import Counter
from datetime import datetime, timezone


def leaves(nodes):
    for node in nodes:
        if node.get('children'):
            yield from leaves(node['children'])
        else:
            yield node


def summarize(records):
    counts = Counter()
    rows = []
    for r in records:
        nodes = list(leaves(r.get('lookthrough', [])))
        keys = sorted({n['stock_key'] for n in nodes if n.get('resolution') == 'eligible_stock'})
        status = r.get('lookthrough_status', 'not_audited')
        counts.update(keys)
        excluded = sorted({n['name'] for n in nodes if n.get('resolution') == 'ineligible_stock'})
        if status != 'complete':
            explanation = 'UNRESOLVED — the final vote count is unknown. Any listed stocks are only verified branches.'
        elif keys:
            explanation = ', '.join(keys)
        elif excluded:
            explanation = '0 eligible stock votes — held stocks lack a verified U.S. exchange listing: ' + '; '.join(excluded)
        else:
            explanation = '0 stock votes — verified non-equity holdings: ' + '; '.join(sorted({n['name'] for n in nodes}))
        rows.append({'id': r['id'], 'status': status, 'eligible_stock_keys': keys,
                     'eligible_vote_count': len(keys) if status == 'complete' else None,
                     'verified_vote_count': len(keys), 'explanation': explanation})
    return {'source_count': len(records), 'resolved_sources': sum(r['status'] == 'complete' for r in rows),
            'verified_eligible_votes': sum(counts.values()),
            'stock_vote_counts': dict(sorted(counts.items(), key=lambda p: (-p[1], p[0]))), 'sources': rows}


def report(snapshot):
    records = snapshot['records']
    summary = summarize(records)
    complete = summary['resolved_sources'] == len(records) and not snapshot.get('failures')
    lines = ['CONSENSUS PORTFOLIO — COMPLETE SOURCE-UNIVERSE HOLDINGS AUDIT',
             'Retrieved: ' + snapshot['retrieved_at'],
             f"Sources inspected: {len(records)}; resolved: {summary['resolved_sources']}; unresolved: {len(records)-summary['resolved_sources']}",
             f"Verified U.S. stock votes: {summary['verified_eligible_votes']}",
             'Status: ' + ('All configured holdings branches resolved.' if complete else 'INCOMPLETE HOLDINGS RESOLUTION. Verified votes below are partial; no new allocation has been applied.'),
             '', 'METHOD',
             'Read the top two direct holdings of every original source. Recursively read the top two of each underlying fund.',
             'One company vote per original source, even when reached through multiple branches. Separate original funds keep their separate votes.',
             'U.S.-exchange listed stocks and verified listed ADRs qualify. Unlisted companies are skipped in the final stock selection; no replacement holdings are invented.',
             'Cash, debt, derivatives, property and verified money-market funds terminate with a reason. An unresolved fund is UNKNOWN, never zero.',
             'Source influence uses original source assets once in the denominator. Underlying fund assets are not added again.',
             'Reports have different dates. Retrieval dates do not imply current holding dates. These weights are not actual company ownership.',
             '', 'VERIFIED COMPANY VOTE COUNTS' + ('' if complete else ' — PARTIAL; UNRESOLVED BRANCHES MAY ADD VOTES')]
    for key, count in summary['stock_vote_counts'].items():
        lines.append(f'{key}: {count}')
    lines += ['', 'EXCLUDED SOURCES'] + snapshot.get('excluded_sources', [])
    lines += ['', 'EVERY SOURCE AND ALL RECURSIVE BRANCHES']
    summaries = {r['id']: r for r in summary['sources']}
    total = sum(r['assets_usd'] for r in records)
    def tree(nodes, depth=1):
        for n in nodes:
            indent = '  '*depth
            weight = f"; holding weight {n['weight_pct']}%" if 'weight_pct' in n else ''
            lines.append(f"{indent}- {n['name']} [{n.get('symbol') or 'no ticker'}]{weight}")
            lines.append(f"{indent}  Result: {n['resolution']}" + (f" -> {n['stock_key']}" if n.get('stock_key') else ''))
            if n.get('reason'): lines.append(indent + '  Reason: ' + n['reason'])
            lines.append(indent + '  Reported by: ' + str(n.get('source')) + ' | Report date: ' + str(n.get('report_date') or 'not provided'))
            if n.get('holdings_source'):
                lines.append(indent + '  Underlying source: ' + n['holdings_source'] + ' | Report date: ' + str(n.get('holdings_date') or 'not provided'))
            if n.get('identity_source'): lines.append(indent + '  Identity source: ' + n['identity_source'])
            tree(n.get('children', []), depth+1)
    for r in sorted(records, key=lambda r:r['id']):
        a=summaries[r['id']]
        lines += ['',r['id']+' — '+r['name'], 'Resolution status: '+a['status'],
                  f"Reported assets: ${r['assets_usd']:,.0f}; source influence: {r['assets_usd']/total*100:.6f}%",
                  'Asset date: '+str(r.get('asset_date') or 'not supplied by source'),
                  'Asset source: '+r['asset_source'], 'Holdings source: '+r['holdings_source'],
                  'Eligible stock votes: '+a['explanation']]
        tree(r.get('lookthrough', []))
    return '\n'.join(lines)+'\n', summary

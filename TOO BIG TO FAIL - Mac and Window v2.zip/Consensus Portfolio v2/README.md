# CONSENSUS PORTFOLIO v2

A local Python portfolio research app with an ultra-dark, sharp-edged glass interface. Its only action is to scan public sources and calculate a model allocation; there is no brokerage connection.

## Run

Extract the full ZIP. On Mac, double-click `Consensus Portfolio.app` or `Start on Mac.command`. On Windows, double-click `Start on Windows.bat`. The launchers use `launch.py` to set up dependencies, start port 8765, wait for readiness, and open the browser. Keep the terminal window open; Ctrl+C stops the server. Python 3.9+ must be installed. Compatible dependency wheels are included, with an online fallback for other platforms. See `START HERE.txt` for setup and port-conflict help.

`python3 launch.py --port 8766` selects another port on Mac; use `py -3 launch.py --port 8766` on Windows.
Or run from this directory:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python app.py
```

Python 3.9 or newer. Internet access is required to rebalance. The saved allocation and its sources remain available offline while the local server is running. This Flask server is for local use; public deployment needs a production server and rate limiting.

## Portfolio rules

1. Scan the configured 166 included source portfolios. Read their top **two direct holdings** and reported asset values. For each underlying fund, recursively read its top two holdings until reaching stocks or identified non-equity assets.
2. Divide each source's assets by the sum of all included source assets. Use fund/account net assets, and disclosed 13F securities value for pension filers. These are not company market caps.
3. Each distinct source gives each distinct stock reached through the holdings tree **one vote** and its full source weight. SPY has no special multiplier. Bonds, cash and properties do not generate stock votes. Underlying funds are resolved to their holdings; their assets are not added again, and repeated branches cannot duplicate a company vote from the original source. Verified money-market funds terminate with issuer classification evidence. Unresolved funds, lookup errors and cycles fail the scan visibly.
4. Require **at least three votes** and a verified U.S. exchange listing. Listed ADRs qualify; OTC-only securities do not. Consolidate the configured GOOG/GOOGL and MOG.A/MOG.B share classes into one company vote per source.
5. Sort by weighted score, then company name for ties. Select up to ten. Leave slots empty if fewer than ten qualify.
6. Normalize selected scores to 100%, using the original two-decimal allocation as the starting percentages (matching the approved research experiment).
7. Fetch each selected company's current, dated USD market cap. Divide its starting allocation percentage by that market cap, then normalize these ratios.
8. Cap each stock at **15%** and repeatedly redistribute excess proportionally among uncapped stocks. If fewer than seven qualify, retain the remainder as explicitly displayed unallocated cash. Final rounding makes stocks plus cash total exactly 100.00%.

See [readmelogic.txt](readmelogic.txt) for the complete plain-language explanation. Stock selection still happens before the market-cap adjustment; this does not choose a different top ten by inverse market cap.

For example, three sources containing a stock qualify it even if they are small. Two very large sources do not meet the three-vote cutoff. Contributing capital determines selection and the starting percentage; inverse company market cap and the 15% cap determine the final target.

## Rebalance and freshness

**Rebalance** starts a background scan and shows progress. The app checks Nasdaq Trader's exchange directories, scans holdings/assets, fetches selected company market caps, applies inverse-cap ratios and the 15% limit, and saves a new snapshot. A complete successful scan resets the freshness clock. The UI displays a holdings-scan warning when **more than seven days** pass, including while the page remains open.

If even one required holdings, source-assets or company-market-cap lookup fails, the entire previous allocation and its original successful-scan timestamp remain unchanged. The UI identifies failed sources. Partial results are retained separately for inspection, never silently blended into the model. Concurrent scans are rejected. Opening the app does not trigger a scan. There is no scheduled daily rebalancing or trading. The 15% ceiling is a target allocation limit; actual holdings may drift between manual updates.

## Sources and limitations

- [Stock Analysis](https://stockanalysis.com/) supplies the configured ETF/mutual-fund holdings and most displayed fund asset values. Its company market-cap pages supply dated USD company values for the final weighting. Security identity, currency and a valuation date within seven days are required; an old value is never substituted after a lookup fails.
- TIAA issuer factsheets supply CREF account and real-estate account net assets. Their exact PDF links are stored with each record.
- [13f.info](https://13f.info/) supplies pension-filer holdings and disclosed securities totals. The scanner selects the latest quarter and prefers a newer corrected filing; same-day restatements take precedence over originals.
- [Nasdaq Trader symbol directories](https://www.nasdaqtrader.com/trader.aspx?id=symboldirdefs) verify U.S. exchange eligibility and identify ETFs.

The **Sources** tab and JSON export contain recursive holdings trees, exact per-record holdings and asset URLs, reporting dates where available, and source notes. A recent retrieval does not mean the underlying report is recent. Many displayed asset values have no stated valuation date; individual source details identify missing dates. Holdings and asset reports can cover different dates.

Reported assets overlap across funds and accounts; their sum is **not unique capital**. A stock's weighted score is source influence, not dollars invested in that stock: this model deliberately does not multiply by the stock's percentage inside each source. Pension 13Fs are partial disclosures, not whole pension portfolios. The configured universe is not every retirement plan or fund in existence. A 401(k), IRA, or Roth account is not itself a fund.

NYC Employees, NYC Teachers, Pennsylvania SERS, and LIRPX remain excluded pending verified holdings. The fixed source universe does not automatically discover new target-date vintages. Source-page changes or service limits can cause scans to fail visibly.

## Files

- `app.py`: local HTTP API, background scan coordination, atomic persistence.
- `engine.py`: portfolio calculation and seven-day freshness rules.
- `sources.py`: public-source readers, filing correction handling, exchange resolution.
- `static/`: HTML, CSS, and browser JavaScript. Portfolio and scan logic run in Python.
- `data/seed.json`: imported research and source configuration.
- `data/state.json`: last applied allocation inputs and provenance.
- `data/history/`: complete successful scan snapshots.
- `data/last_scan_attempt.json`: partial inputs from the most recent incomplete scan.
- `tests/test_portfolio.py`: calculation, parser, scan persistence, and API regression tests.

No credentials or API keys are needed. New portfolio rules should go in `engine.py`; new data providers should go in `sources.py`.

## Verify

```sh
.venv/bin/python -m unittest discover -s tests -v
```

Browser verification also covers a source rebalance, allocation totals, source search/filter, source links, methodology, JSON download, mobile layout, and the overdue warning.

## Current audit status — September 13, 2026

All 167 original sources were audited. The user excluded LIRPX because BlackRock Russell 1000 Index Fund F remains unresolved. The corrected allocation is now applied using all 166 remaining sources and 284 verified U.S. company votes. LIRPX is absent from the asset denominator and future scans. Its unresolved record is retained in exclusion metadata and the original audit.

The model now selects ten stocks. Public data was retrieved September 13, 2026 at 08:32 UTC; applying the corrected allocation does not reset that retrieval timestamp. Sources and exports contain the applied holdings trees. Unknown no-ticker instruments still fail visibly instead of being assigned zero. See Current Portfolio.txt and the app Sources view/export for the allocation and source links.

## Applied weighting update — September 13, 2026

The app now uses inverse company market caps and iterative 15% capping. The earlier allocation in the audit-status section describes the pre-adjustment source consensus. The current API and export calculate the new targets from saved holdings and dated market caps. Historical backtest logic is not part of the application.

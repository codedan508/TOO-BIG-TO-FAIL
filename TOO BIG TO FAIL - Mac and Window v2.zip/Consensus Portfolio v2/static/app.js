const $ = (id) => document.getElementById(id);
const colors = ['#e2e3dc','#788988','#b5b3a5','#78808b','#b1b8bb','#646d73','#8c9497','#a69c8b','#697a79','#53636b'];
let state, view = 'portfolio', previousJob, polling = false;
const escapeHTML = (s) => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = (n) => n >= 1e12 ? `$${(n/1e12).toFixed(2)}T` : n >= 1e9 ? `$${(n/1e9).toFixed(2)}B` : `$${(n/1e6).toFixed(2)}M`;
const pct = (n) => Number(n).toFixed(2);
const date = (s) => s ? new Date(s.length===10 ? s+'T12:00:00' : s).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'}) : 'Not provided';
const safeLink = (url) => {try {const u=new URL(url);return u.protocol==='https:'?escapeHTML(u.href):'#';}catch{return '#';}};

function changeView(next) {
  view=next;
  for (const key of ['portfolio','sources','method']) $(key+'-view').hidden=key!==view;
  document.querySelectorAll('nav [data-view]').forEach(b=>{b.classList.toggle('active',b.dataset.view===view);if(b.dataset.view===view)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
  if(view==='sources' && state) renderSources();
}
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>changeView(b.dataset.view)));

function render() {
  const p=state.portfolio,j=state.job,running=j.status==='running';
  $('rebalance').disabled=running;
  $('rebalance-label').textContent=running?'Scanning…':'Rebalance';
  document.body.classList.toggle('scanning',running);
  $('nav-count').textContent=p.source_count;
  $('total-assets').textContent=money(p.total_assets_usd);
  $('source-count').textContent=p.source_count;
  $('total-foot').textContent=p.allocation_version?'100.00%':p.selected.length?'100.00%':'0.00%';
  $('allocation-foot').textContent=p.allocation_version?'3+ source votes · 15% maximum per stock · manual rebalance':'Previous allocation rules · run Rebalance to update';
  $('last-scan').textContent=state.last_successful_scan?date(state.last_successful_scan):'Live scan not yet completed';
  $('scan-context').textContent=state.last_successful_scan?`${Math.floor(state.freshness.age_days)} days ago · saved locally`:`Research seeded ${date(state.seed_date)}`;
  $('freshness').hidden=!state.freshness.needs_scan;
  $('freshness-text').textContent=state.freshness.reason==='lookthrough_required'?'This saved allocation predates the underlying-fund correction. Run Rebalance to resolve the holdings chains.':state.freshness.reason==='market_cap_required'?'This saved allocation uses the previous weighting. Run Rebalance to fetch company market caps and apply the 15% limit.':state.freshness.reason==='overdue'?'More than 1 week has passed since the last complete scan. Run a holdings scan to rebalance.':'This allocation uses the saved research snapshot. Run Rebalance for a complete public-source scan.';
  $('allocation-strip').innerHTML=p.selected.map((r,i)=>`<span style="width:${r.allocation_pct}%;--c:${colors[i]}" title="${escapeHTML(r.ticker)} · ${pct(r.allocation_pct)}%"></span>`).join('');
  if(p.cash_allocation_pct) $('allocation-strip').innerHTML+=`<span style="width:${p.cash_allocation_pct}%;--c:#444" title="Unallocated cash · ${pct(p.cash_allocation_pct)}%"></span>`;
  $('allocation-strip').setAttribute('aria-label',p.selected.map(r=>`${r.ticker} ${pct(r.allocation_pct)} percent`).join(', ')+(p.cash_allocation_pct?`, unallocated cash ${pct(p.cash_allocation_pct)} percent`:''));
  $('allocation-body').innerHTML=p.selected.length?p.selected.map((r,i)=>`<tr><td><div class="asset-cell"><span class="asset-dot" style="--c:${colors[i]}"></span><div class="asset-symbol"><strong>${escapeHTML(r.ticker)}</strong><span>${escapeHTML(r.name)}</span></div></div></td><td><span class="votes">${r.votes}</span></td><td class="allocation-value">${pct(r.allocation_pct)}<small>%</small></td><td><button class="row-arrow" data-stock="${escapeHTML(r.key)}" aria-label="Inspect ${escapeHTML(r.name)} contributors">↗</button></td></tr>`).join(''):'<tr><td class="empty" colspan="4">No stocks meet the three-vote and U.S. listing requirements.</td></tr>';
  if(p.cash_allocation_pct) $('allocation-body').innerHTML+=`<tr><td><div class="asset-symbol"><strong>Unallocated cash</strong><span>Not enough qualifying stocks to invest 100% within the 15% limit</span></div></td><td>—</td><td class="allocation-value">${pct(p.cash_allocation_pct)}<small>%</small></td><td></td></tr>`;
  $('scan-progress').hidden=j.status==='idle';
  if(j.status!=='idle') {
    $('scan-phase').textContent=j.phase;
    $('scan-numbers').textContent=`${j.completed} / ${j.total}`;
    $('scan-fill').style.width=`${j.total?j.completed/j.total*100:0}%`;
    $('scan-detail').textContent=running?(j.current?`Checked ${j.current}`:'Reading the exchange directories…'):j.status==='complete'?`${j.updated} source portfolios and ${j.market_caps_updated||0} company market caps refreshed. The 15%-capped allocation is saved.`:`${j.updated} source portfolios refreshed; ${j.failures.length} required lookups failed. The previous snapshot and scan date are retained.`;
    $('review-scan').hidden=!j.failures.length;
  } else if(state.last_attempt?.failures?.length) {
    $('scan-progress').hidden=false;
    $('scan-phase').textContent='Previous scan incomplete · saved allocation retained';
    $('scan-numbers').textContent=`${state.last_attempt.updated} / ${state.last_attempt.total}`;
    $('scan-detail').textContent=`${state.last_attempt.failures.length} sources could not be refreshed. Retry with Rebalance.`;
    $('review-scan').hidden=false;
  }
  if(previousJob==='running' && j.status==='complete')toast('Scan complete. Your model allocation has been updated.');
  previousJob=j.status;
  if(view==='sources')renderSources();
}

function latestSource(record) {
  const attempt=state.lookup_attempt;
  return attempt && [...attempt.refreshed_records,...(attempt.unresolved_records||[])].find(r=>r.id===record.id) || record;
}
function leafNodes(nodes) {return (nodes||[]).flatMap(n=>n.children?leafNodes(n.children):[n]);}
function voteSummary(record) {
  if(!record.lookthrough)return 'Not yet audited';
  const leaves=leafNodes(record.lookthrough);
  const stocks=[...new Set(leaves.filter(n=>n.resolution==='eligible_stock').map(n=>n.stock_key))].sort();
  const unresolved=record.lookthrough_status!=='complete';
  if(stocks.length)return `${stocks.join(', ')} · ${stocks.length} votes${unresolved?' · INCOMPLETE':''}`;
  if(unresolved)return 'UNRESOLVED — vote count unknown';
  if(leaves.some(n=>n.resolution==='ineligible_stock'))return '0 eligible votes — held stocks lack a U.S. exchange listing';
  return '0 stock votes — verified non-equity holdings';
}
function renderSources() {
  const query=$('source-search').value.toLowerCase().trim(),type=$('source-type').value;
  const all=state.records.map(r=>({saved:r,audit:latestSource(r)}));
  const rows=all.filter(({saved:r,audit:a})=>(type==='all'||r.kind===type)&&`${r.id} ${r.name} ${JSON.stringify(a.lookthrough||a.holdings)}`.toLowerCase().includes(query)).sort((a,b)=>b.saved.assets_usd-a.saved.assets_usd);
  const audited=all.filter(({audit:a})=>a.lookthrough_status==='complete').length;
  const votes=all.reduce((sum,{audit:a})=>sum+new Set(leafNodes(a.lookthrough).filter(n=>n.resolution==='eligible_stock').map(n=>n.stock_key)).size,0);
  $('source-result-count').textContent=`${rows.length} / ${all.length} ENTRIES`;
  $('source-audit-summary').textContent=`${audited} / ${all.length} sources resolved · ${votes} verified U.S. stock votes. `+(state.lookup_attempt?'Latest holdings audit is incomplete and has not been applied. Assets and weights below belong to the saved allocation.':'One company vote per original source, including stocks reached through underlying funds.');
  $('source-body').innerHTML=rows.length?rows.map(({saved:r,audit:a})=>`<tr><td><span class="source-id">${escapeHTML(r.id)}</span>${r.name!==r.id?`<span class="source-name">${escapeHTML(r.name)}</span>`:''}</td><td>${money(r.assets_usd)}</td><td>${state.portfolio.fund_weights[r.id].toFixed(3)}%</td><td><strong>${escapeHTML(voteSummary(a))}</strong><span class="source-name">${a.holdings.map(h=>escapeHTML(h.name)).join('<br>')}</span></td><td>${date(r.asset_date)}</td><td><button class="row-arrow" data-source="${escapeHTML(r.id)}" aria-label="Inspect source ${escapeHTML(r.id)}">↗</button></td></tr>`).join(''):'<tr><td colspan="6" class="empty">No sources match your search.</td></tr>';
  $('source-disclaimer').textContent=`Pension figures represent 13F-disclosed securities, not the entire retirement system. Fund-of-fund assets can overlap. Source reports use different dates. Excluded pending verified holdings: ${state.excluded_sources.join('; ')}.`;
}

function sourceLookthrough(record) {
  const latest=latestSource(record),attempt=state.lookup_attempt;
  return (latest!==record?`<p>Latest lookup ${date(attempt.attempt.finished_at)}. The full scan is incomplete; these results have not been applied to the allocation.</p>`:'')+`<p><strong>${escapeHTML(voteSummary(latest))}</strong></p>`+holdingTree(latest.lookthrough);
}
function holdingTree(nodes) {
  if(!nodes) return '<p>Underlying holdings have not been scanned yet.</p>';
  return '<ul class="holding-tree">'+nodes.map(n=>`<li><strong>${escapeHTML(n.name)}</strong>${n.symbol && n.symbol!=='n/a'?` (${escapeHTML(n.symbol)})`:''}<small>${escapeHTML(n.resolution?.replaceAll('_',' '))}${n.stock_key?` · ${escapeHTML(n.stock_key)}`:''}</small>${n.reason?`<small>${escapeHTML(n.reason)}</small>`:''}${n.identity_source?`<small><a href="${safeLink(n.identity_source)}" target="_blank" rel="noopener noreferrer">Holding identity source ↗</a></small>`:''}<small><a href="${safeLink(n.holdings_source||n.source)}" target="_blank" rel="noopener noreferrer">Holdings source ↗</a> · ${date(n.holdings_date||n.report_date)}</small>${n.children?holdingTree(n.children):''}</li>`).join('')+'</ul>';
}
function openDialog(title,eyebrow,html){$('dialog-title').textContent=title;$('dialog-eyebrow').textContent=eyebrow;$('dialog-content').innerHTML=html;$('detail-dialog').showModal();}
$('close-dialog').addEventListener('click',()=>$('detail-dialog').close());
$('detail-dialog').addEventListener('click',e=>{if(e.target===$('detail-dialog')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.target.close();}});
document.addEventListener('click',e=>{
  const stockButton=e.target.closest('[data-stock]'),sourceButton=e.target.closest('[data-source]');
  if(stockButton){const r=state.portfolio.selected.find(x=>x.key===stockButton.dataset.stock)||state.portfolio.ranked.find(x=>x.key===stockButton.dataset.stock);openDialog(r.name,`${r.ticker} / ${r.exchange}`,`<p>${r.votes} distinct source votes contribute a ${pct(r.score_pct)}% weighted score. That score determines the original allocation before the company-size adjustment.</p>${r.market_cap_usd?`<div class="detail-row"><span>Original allocation</span><span>${pct(r.base_allocation_pct)}%</span></div><div class="detail-row"><span>Company market cap (USD)</span><span>${money(r.market_cap_usd)}</span></div><p><a href="${safeLink(r.market_cap_source)}" target="_blank" rel="noopener noreferrer">Market-cap source ↗</a> · valued ${date(r.market_cap_date)} · retrieved ${date(r.market_cap_retrieved_at)}</p><p>Divide the original allocation by company market cap, normalize the ratios, then limit each stock to 15% and share any excess among the remaining stocks in proportion to their ratios. Final target: <strong>${pct(r.allocation_pct)}%</strong>.</p>`:''}`+r.contributors.map(id=>{const f=state.records.find(x=>x.id===id);return `<div class="detail-row"><a href="${safeLink(f.holdings_source)}" target="_blank" rel="noopener noreferrer">${escapeHTML(id)} ↗<small>${escapeHTML(f.holdings_date?date(f.holdings_date):'Holdings date not recorded')}</small></a><span>${state.portfolio.fund_weights[id].toFixed(3)}%<small>${money(f.assets_usd)} reported assets</small></span></div>${holdingTree(f.lookthrough)}`;}).join(''));}
  if(sourceButton){const r=state.records.find(x=>x.id===sourceButton.dataset.source);openDialog(r.id,'SOURCE PORTFOLIO',`<p>${escapeHTML(r.name)}</p><div class="detail-row"><span>Reported assets</span><span>${money(r.assets_usd)}</span></div><div class="detail-row"><span>Weight in model</span><span>${state.portfolio.fund_weights[r.id].toFixed(4)}%</span></div><div class="detail-row"><span>Asset valuation date</span><span>${date(r.asset_date)}</span></div><div class="detail-row"><span>Holdings report date</span><span>${date(r.holdings_date)}</span></div><p>${escapeHTML(r.source_note)}</p><div class="detail-row"><span>Holdings</span><a href="${safeLink(r.holdings_source)}" target="_blank" rel="noopener noreferrer">Read holdings source ↗</a></div><div class="detail-row"><span>Assets</span><a href="${safeLink(r.asset_source)}" target="_blank" rel="noopener noreferrer">Read asset source ↗</a></div><h3>Underlying holdings</h3>${sourceLookthrough(r)}`);}
});
$('source-search').addEventListener('input',renderSources);$('source-type').addEventListener('change',renderSources);
$('review-scan').addEventListener('click',()=>{const failures=state.job.failures.length?state.job.failures:state.last_attempt?.failures||[];openDialog('A scan with gaps.','PREVIOUS ALLOCATION RETAINED','<p>Every included source must return usable data before a new snapshot is applied. These errors did not reset the weekly scan clock.</p>'+failures.map(f=>`<div class="detail-row"><span>${escapeHTML(f.id)}<small>${escapeHTML(f.message)}</small></span>${f.url?`<a href="${safeLink(f.url)}" target="_blank" rel="noopener noreferrer">Source ↗</a>`:''}</div>`).join(''));});
function toast(message){$('toast').textContent=message;$('toast').hidden=false;setTimeout(()=>$('toast').hidden=true,5500);}
async function refresh(){if(polling)return;polling=true;try{const response=await fetch('/api/state');if(!response.ok)throw Error('State unavailable');state=await response.json();$('connection-error').hidden=true;render();}catch(e){$('connection-error').hidden=false;$('rebalance').disabled=true;}finally{polling=false;}}
$('rebalance').addEventListener('click',async()=>{$('rebalance').disabled=true;try{const response=await fetch('/api/rebalance',{method:'POST'});if(!response.ok){const error=await response.json();throw Error(error.error||'Could not start scan');}await refresh();}catch(e){toast(e.message);$('rebalance').disabled=false;}});
refresh();setInterval(()=>{if(state?.job.status==='running')refresh();},1500);setInterval(refresh,60000);

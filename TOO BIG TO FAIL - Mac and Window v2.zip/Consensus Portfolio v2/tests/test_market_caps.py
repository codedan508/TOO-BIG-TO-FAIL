import copy
import json
import random
import unittest
from datetime import datetime, timedelta, timezone
from fractions import Fraction as F
from pathlib import Path
from unittest.mock import patch
from bs4 import BeautifulSoup
import app as server
from engine import build_portfolio, capped_allocations, ALLOCATION_VERSION
from sources import parse_market_cap
import test_portfolio as fixtures
from test_portfolio import record, listings


def cap(t, value=1000000000):
    return {'ticker':t,'currency':'USD','market_cap_usd':value,'market_cap_date':'2026-09-11',
            'retrieved_at':'2026-09-13T00:00:00+00:00','url':'https://example.org/market-cap/'}


class AllocationRules(unittest.TestCase):
    def test_approved_current_basket_matches_experiment(self):
        expected={'AAPL':15,'MOG.A':15,'NVDA':15,'SNOW':15,'TSM':11.55,'ASML':9.75,'AVGO':6.39,'MU':5.84,'MSFT':3.47,'AMZN':3}
        caps={t:cap(t,v) for t,v in {'AAPL':4.85e12,'MOG.A':11.62e9,'NVDA':5.27e12,'SNOW':115.95e9,'TSM':1.98e12,'ASML':658.99e9,'AVGO':1.73e12,'MU':1.10e12,'MSFT':3.68e12,'AMZN':2.77e12}.items()}
        base={'AAPL':44.38,'MOG.A':0.72,'NVDA':45.33,'SNOW':0.91,'TSM':2.92,'ASML':0.82,'AVGO':1.41,'MU':0.82,'MSFT':1.63,'AMZN':1.06}
        rows=[record(f'{t}-{i}',weight,[t]) for t,weight in base.items() for i in range(3)]
        result=build_portfolio(rows,listings(*base),caps)
        self.assertEqual({r['ticker']:r['allocation_pct'] for r in result['selected']},expected)
        self.assertEqual(result['cash_allocation_pct'],0)

    def test_repeated_caps_and_proportional_remainder(self):
        result,cash=capped_allocations([F(n) for n in [10000,1000,100,10,4,3,2,1]],list('ABCDEFGH'))
        self.assertEqual(result,[15,15,15,15,15,12.5,8.33,4.17])
        self.assertEqual(cash,0)

    def test_infeasible_cap_leaves_cash(self):
        for n in range(7):
            allocations,cash=capped_allocations([F(1)]*n,list('ABCDEF')[:n])
            self.assertEqual(allocations,[15]*n)
            self.assertEqual(cash,100-15*n)

    def test_equal_seven_rounds_and_random_conservation(self):
        self.assertEqual(capped_allocations([F(1)]*7,list('ABCDEFG'))[0],[14.29]*4+[14.28]*3)
        rng=random.Random(15)
        for n in range(1,11):
            for _ in range(40):
                out,cash=capped_allocations([F(rng.randint(1,10**9)) for i in range(n)],[str(i) for i in range(n)])
                self.assertEqual(round(sum(out)+cash,2),100)
                self.assertTrue(all(0<=p<=15 for p in out))

    def test_missing_wrong_currency_and_invalid_caps_rejected(self):
        rows=[record(str(i),stocks=['A']) for i in range(3)]
        for invalid in ({}, {'A':cap('B')}, {'A':{**cap('A'),'currency':'EUR'}}, {'A':cap('A',0)}, {'A':cap('A',float('nan'))}, {'A':{**cap('A'),'market_cap_date':None}}):
            with self.assertRaises(ValueError):build_portfolio(rows,listings('A'),invalid)


class MarketCapParsing(unittest.TestCase):
    def page(self,t='TSM',currency='USD',days=2,value='1.98 trillion'):
        date=(datetime.now(timezone.utc)-timedelta(days=days)).strftime('%B %d, %Y')
        return BeautifulSoup(f'<main>Company ({t}) NYSE: {t} · Real-Time Price · {currency} Company has a market cap or net worth of ${value} as of {date}.</main>','html.parser')

    def test_company_usd_cap_date_and_provenance(self):
        for t in ['TSM','MOG.A','AAPL']:
            out=parse_market_cap(self.page(t),t,'https://example.org/market-cap/',b'page')
            self.assertEqual(out['market_cap_usd'],1980000000000)
            self.assertEqual(out['currency'],'USD')
            self.assertEqual(len(out['sha256']),64)
            self.assertTrue(out['retrieved_at'])

    def test_identity_currency_missing_date_stale_and_future_fail(self):
        for soup in [self.page('WRONG'),self.page(currency='TWD'),self.page(days=8),self.page(days=-1),BeautifulSoup('<main>TSM Market Cap 1.98T</main>','html.parser')]:
            with self.assertRaises(ValueError):parse_market_cap(soup,'TSM','https://example.org/')


class FullScanMarketCaps(fixtures.ScanPersistence):
    def test_market_cap_failure_retains_entire_previous_model_and_date(self):
        state=copy.deepcopy(self.state)
        state.update(market_caps={'A':cap('A')}, allocation_version=ALLOCATION_VERSION,lookthrough_version=server.LOOKTHROUGH_VERSION)
        (self.data/'seed.json').write_text(json.dumps(state))
        before=server.portfolio_for_state(state)
        with patch.object(server,'scan_record',side_effect=lambda r:{**copy.deepcopy(r),'assets_usd':200}),patch.object(server,'scan_market_cap',side_effect=ValueError('Market cap unavailable')):
            server.run_scan()
        saved=server.load_state()
        self.assertEqual(saved['records'],state['records'])
        self.assertEqual(saved['market_caps'],state['market_caps'])
        self.assertEqual(saved['last_successful_scan'],state['last_successful_scan'])
        self.assertEqual(server.portfolio_for_state(saved),before)
        self.assertEqual(server.job['status'],'failed')
        self.assertEqual(saved['last_attempt']['failures'][0]['kind'],'company_market_cap')
        self.assertTrue(self.client.get('/api/state').json['last_attempt']['failures'])

    def test_market_cap_success_uses_fresh_lookup_and_exports_new_rules(self):
        with patch.object(server,'scan_record',side_effect=copy.deepcopy),patch.object(server,'scan_market_cap',return_value=cap('A',2e9)) as lookup:
            server.run_scan()
        lookup.assert_called_once_with('A')
        self.assertEqual(server.load_state()['market_caps']['A']['market_cap_usd'],2e9)
        output=self.client.get('/api/export').json
        self.assertEqual(output['rules']['max_position_pct'],15)
        self.assertEqual(output['allocation_version'],ALLOCATION_VERSION)
        self.assertEqual(output['portfolio']['selected'][0]['allocation_pct'],15)

    def test_legacy_snapshot_explicitly_needs_market_cap_scan(self):
        state=copy.deepcopy(self.state);state['lookthrough_version']=server.LOOKTHROUGH_VERSION
        (self.data/'seed.json').write_text(json.dumps(state))
        self.assertEqual(self.client.get('/api/state').json['freshness']['reason'],'market_cap_required')


if __name__=='__main__':unittest.main()

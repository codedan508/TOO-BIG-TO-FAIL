import copy
import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch

from bs4 import BeautifulSoup
import app as server
from engine import build_consensus as build_portfolio, freshness, normalized_allocations
from sources import date_from, parse_13f_info, parse_stockanalysis, resolve_holdings, HoldingResolver, HoldingResolutionError
from audit_report import summarize, report


def record(key, assets=100, stocks=None):
    return {'id': key, 'name': key, 'assets_usd': assets, 'asset_date': None,
            'stock_keys': stocks or [], 'scan_url': 'https://example.org/fund',
            'holdings': [{'name': s, 'symbol': s, 'kind': 'stock'} for s in stocks or []]}


def listings(*symbols):
    return {s: {'name': s, 'ticker': s, 'exchange': 'Nasdaq', 'eligible': True} for s in symbols}


class PortfolioRules(unittest.TestCase):
    def test_cutoff_is_raw_votes_not_money_and_no_spy_bonus(self):
        rows = [record('SPY', 10000, ['RICH']), record('a', 1, ['SMALL']),
                record('b', 1, ['SMALL']), record('c', 1, ['SMALL'])]
        result = build_portfolio(rows, listings('RICH', 'SMALL'))
        self.assertEqual([s['ticker'] for s in result['selected']], ['SMALL'])
        self.assertEqual(result['ranked'][0]['votes'], 1)
        self.assertEqual(result['selected'][0]['allocation_pct'], 100)

    def test_denominator_includes_nonstock_funds(self):
        rows = [record(str(i), 100, ['A', 'B']) for i in range(3)] + [record('bonds', 700)]
        result = build_portfolio(rows, listings('A', 'B'))
        self.assertAlmostEqual(sum(result['fund_weights'].values()), 100)
        self.assertEqual(result['selected'][0]['score_pct'], 30)
        self.assertEqual([s['allocation_pct'] for s in result['selected']], [50, 50])

    def test_duplicate_company_is_one_vote_and_foreign_excluded(self):
        rows = [record(str(i), stocks=['A', 'A', 'foreign']) for i in range(3)]
        result = build_portfolio(rows, listings('A'))
        self.assertEqual(len(result['selected']), 1)
        self.assertEqual(result['selected'][0]['votes'], 3)

    def test_ten_max_and_deterministic_ties(self):
        rows = [record(f'{s}-{i}', stocks=[s]) for s in 'LKJIHGFEDCBA' for i in range(3)]
        result = build_portfolio(rows, listings(*'ABCDEFGHIJKL'))
        self.assertEqual([s['ticker'] for s in result['selected']], list('ABCDEFGHIJ'))
        self.assertEqual(result['qualified_count'], 12)

    def test_exact_rounding_and_empty_result(self):
        self.assertEqual(normalized_allocations([Decimal(1)] * 3), [33.34, 33.33, 33.33])
        self.assertEqual(normalized_allocations([]), [])
        self.assertEqual(build_portfolio([record('x')], {})['selected'], [])

    def test_invalid_inputs_rejected(self):
        for assets in (0, -1, float('nan'), float('inf')):
            with self.assertRaises(ValueError):
                build_portfolio([record('x', assets)], {})
        with self.assertRaises(ValueError):
            build_portfolio([record('x'), record('x')], {})

    def test_week_boundary_and_seed(self):
        now = datetime(2026, 9, 13, tzinfo=timezone.utc)
        self.assertTrue(freshness(None, now)['needs_scan'])
        self.assertFalse(freshness((now-timedelta(days=7)).isoformat(), now)['needs_scan'])
        self.assertTrue(freshness((now-timedelta(days=7, seconds=1)).isoformat(), now)['needs_scan'])


class SourceParsing(unittest.TestCase):
    def test_percent_weight_header_and_unknown_missing_ticker(self):
        soup=BeautifulSoup('''<table><tr><th>No.</th><th>Symbol</th><th>Name</th><th>% Weight</th></tr>
        <tr><td>1</td><td>A</td><td>Company A</td><td>15.05%</td></tr>
        <tr><td>2</td><td>n/a</td><td>Mystery investment</td><td>8.20%</td></tr></table>''','html.parser')
        _, held, _=parse_stockanalysis(soup)
        self.assertEqual([h['weight_pct'] for h in held],[15.05,8.2])
        root=record('x');root['holdings']=held
        with self.assertRaisesRegex(HoldingResolutionError,'Unclassified holding'):
            HoldingResolver(listings('A'),{}).resolve(root)

    def test_first_reporting_date_not_later_disclaimer(self):
        self.assertEqual(date_from('As of 6/30/2026. Waiver expired as of December 31, 2021'), '2026-06-30')

    def test_stock_and_bond_classification_and_two_only(self):
        soup = BeautifulSoup('''<p>Assets 4.25B As of Sep 1, 2026</p><table>
        <tr><th>No.</th><th>Symbol</th><th>Name</th></tr>
        <tr><td>1</td><td><a href="/stocks/nvda/">NVDA</a></td><td>NVIDIA</td></tr>
        <tr><td>2</td><td>T.4.25 2030</td><td>United States Treasury Notes</td></tr>
        <tr><td>3</td><td>AAPL</td><td>Apple</td></tr></table>''', 'html.parser')
        assets, held, date = parse_stockanalysis(soup)
        self.assertEqual(assets, 4250000000)
        self.assertEqual([h['kind'] for h in held], ['stock', 'other'])
        self.assertEqual(date, '2026-09-01')

    def test_13f_restatement_over_original_and_dollars_in_thousands(self):
        soup = BeautifulSoup('''<table><tr><th>Quarter</th><th>Holdings</th><th>Value ($000)</th></tr>
        <tr><td>Q2 2026</td><td>3002</td><td>782,014,439</td><td>NVDA, AAPL, ORCC</td><td>13F-HR</td><td>8/24/2026</td><td>019</td></tr>
        <tr><td>Q2 2026</td><td>3002</td><td>108,615,536</td><td>NVDA, AAPL, MSFT</td><td>RESTATEMENT</td><td>8/24/2026</td><td>020</td></tr>
        <tr><td>Q1 2026</td><td>2925</td><td>99</td><td>MSFT, AAPL</td><td>RESTATEMENT</td><td>8/25/2026</td><td>021</td></tr></table>''', 'html.parser')
        # Sparse old filings must not invalidate a complete newer filing.
        row = BeautifulSoup('<tr><td>Q4 2025</td><td>1</td><td>99</td><td>FTAI</td><td>13F-HR</td><td>2/15/2026</td><td>001</td></tr>', 'html.parser')
        soup.table.append(row.tr)
        assets, held, date = parse_13f_info(soup)
        self.assertEqual(assets, 108615536000)
        self.assertEqual(date, '2026-06-30')
        self.assertEqual([h['symbol'] for h in held], ['NVDA', 'AAPL'])

    def test_share_classes_and_etfs(self):
        directory = listings('GOOG', 'GOOGL', 'VOO')
        directory['VOO'].update(is_fund=True, eligible=False)
        r, _ = resolve_holdings(record('x', stocks=['GOOG', 'GOOGL']), directory, {})
        self.assertEqual(r['stock_keys'], ['GOOGL'])
        resolver = HoldingResolver(directory, {}, loader=lambda url: {'holdings': record('child', stocks=['GOOG','GOOGL'])['holdings'], 'holdings_source': url, 'holdings_date': '2026-07-31'})
        r, _ = resolver.resolve(record('x', stocks=['VOO']))
        self.assertEqual(r['stock_keys'], ['GOOGL'])
        self.assertEqual(r['lookthrough'][0]['kind'], 'fund')


class RecursiveHoldings(unittest.TestCase):
    def test_incomplete_votes_remain_unknown_in_audit_summary(self):
        root=record('x');root['holdings']=[{'name':'Unknown Fund','symbol':'n/a','kind':'fund'},{'name':'A','symbol':'A','kind':'stock'}]
        with self.assertRaises(HoldingResolutionError) as caught:
            HoldingResolver(listings('A'),{}).resolve(root)
        summary=summarize([caught.exception.record])
        self.assertEqual(summary['verified_eligible_votes'],1)
        self.assertIsNone(summary['sources'][0]['eligible_vote_count'])
        self.assertIn('UNRESOLVED',summary['sources'][0]['explanation'])

    def test_nested_branches_deduplicate_and_preserve_original_assets(self):
        directory = listings('A', 'B')
        calls = []
        def fund(t): return {'name': t, 'symbol': t, 'kind': 'fund'}
        def loader(url):
            calls.append(url)
            hs = [fund('CHILD'), fund('CHILD')] if '/PARENT/' in url else record('child', stocks=['A','B'])['holdings']
            return {'holdings': hs, 'holdings_source': url, 'holdings_date': '2026-07-31'}
        resolver = HoldingResolver(directory, {}, loader)
        rows=[]
        for i in range(3):
            root=record(str(i),100);root['holdings']=[fund('PARENT'),fund('CHILD')]
            row, _=resolver.resolve(root);rows.append(row)
            self.assertEqual(row['stock_keys'], ['A','B'])
            self.assertEqual(row['assets_usd'],100)
            self.assertEqual(row['lookthrough'][0]['children'][0]['children'][0]['stock_key'],'A')
        self.assertEqual(len(calls),2)
        result=build_portfolio(rows,directory)
        self.assertEqual(result['total_assets_usd'],300)
        self.assertEqual(result['selected'][0]['votes'],3)
        self.assertEqual(result['selected'][0]['allocation_pct'],50)

    def test_unknown_fund_and_cycle_fail_instead_of_empty_votes(self):
        root=record('x');root['holdings']=[{'name':'Unknown Fund','symbol':'n/a','kind':'other'}]
        with self.assertRaisesRegex(ValueError,'Unresolved underlying fund'):
            HoldingResolver({},{}).resolve(root)
        root['holdings'][0]['symbol']='LOOP'
        resolver=HoldingResolver({}, {}, lambda url: {'holdings':root['holdings']*2,'holdings_source':url,'holdings_date':None})
        with self.assertRaisesRegex(ValueError,'cycle'):
            resolver.resolve(root)

    def test_unresolved_branch_keeps_other_branch_inspectable(self):
        root=record('x');root['holdings']=[{'name':'Unknown Fund','symbol':'n/a','kind':'fund'}, {'name':'A','symbol':'A','kind':'stock'}]
        with self.assertRaises(HoldingResolutionError) as caught:
            HoldingResolver(listings('A'),{}).resolve(root)
        partial=caught.exception.record
        self.assertEqual(partial['lookthrough_status'],'incomplete')
        self.assertEqual(partial['lookthrough'][0]['resolution'],'unresolved')
        self.assertEqual(partial['lookthrough'][1]['stock_key'],'A')
        self.assertEqual(partial['stock_keys'],['A'])

    def test_failed_lookup_has_no_stale_fallback(self):
        def fail(url): raise ValueError('unavailable')
        root=record('x',stocks=['STALE']);root['holdings']=[{'name':'Child Fund','symbol':'CHILD','kind':'fund'}]
        with self.assertRaisesRegex(ValueError,'unavailable'):
            HoldingResolver({}, {}, fail).resolve(root)
        self.assertEqual(root['stock_keys'],['STALE'])

    def test_explicit_nonstock_terminal_and_separate_scan_caches(self):
        root=record('x');root['holdings']=[{'name':'United States Treasury Notes','symbol':'','kind':'other'}]
        out,_=HoldingResolver({},{}).resolve(root)
        self.assertEqual(out['stock_keys'],[])
        self.assertEqual(out['lookthrough'][0]['resolution'],'non_stock')
        calls=[]
        def loader(url):
            calls.append(url)
            return {'holdings':root['holdings']*2,'holdings_source':url,'holdings_date':None}
        root2=record('x');root2['holdings']=[{'name':'Bond Fund','symbol':'BONDX','kind':'fund'}]
        for _ in range(2): HoldingResolver({}, {}, loader).resolve(root2)
        self.assertEqual(len(calls),2)


class ScanPersistence(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.data = Path(self.temp.name)
        self.state = {'records': [record(str(i), stocks=['A']) for i in range(3)],
                      'listings': listings('A'), 'aliases': {}, 'last_successful_scan': '2026-09-01T00:00:00+00:00',
                      'last_attempt': None, 'seed_date': '2026-09-01', 'snapshot_label': 'Test', 'excluded_sources': []}
        (self.data/'seed.json').write_text(json.dumps(self.state))
        self.patches = [patch.object(server, 'DATA', self.data), patch.object(server, 'STATE', self.data/'state.json'),
                        patch.object(server, 'job', {'id': 'test', 'status': 'running', 'completed': 0, 'updated': 0, 'total': 3, 'failures': []}),
                        patch.object(server, 'exchange_directory', return_value=listings('A')),
                        patch.object(server, 'scan_market_cap', return_value={'ticker':'A', 'currency':'USD', 'market_cap_usd':1000000000, 'market_cap_date':'2026-09-11', 'retrieved_at':'2026-09-13T00:00:00+00:00', 'url':'https://example.org/A/market-cap/'})]
        for p in self.patches: p.start()
        self.client = server.app.test_client()

    def tearDown(self):
        for p in reversed(self.patches): p.stop()
        self.temp.cleanup()

    def test_failure_keeps_portfolio_and_timestamp(self):
        def scan(r):
            if r['id'] == '1': raise ValueError('Unavailable')
            return {**copy.deepcopy(r), 'assets_usd': 200}
        with patch.object(server, 'scan_record', side_effect=scan): server.run_scan()
        saved = server.load_state()
        self.assertEqual(saved['records'], self.state['records'])
        self.assertEqual(saved['last_successful_scan'], self.state['last_successful_scan'])
        self.assertEqual(server.job['status'], 'failed')
        self.assertEqual(len(saved['last_attempt']['failures']), 1)

    def test_success_persists_and_exports_provenance(self):
        with patch.object(server, 'scan_record', side_effect=lambda r: {**copy.deepcopy(r), 'assets_usd': 200}): server.run_scan()
        saved = server.load_state()
        self.assertNotEqual(saved['last_successful_scan'], self.state['last_successful_scan'])
        self.assertEqual(server.job['status'], 'complete')
        self.assertTrue((self.data/'history/test.json').exists())
        output = self.client.get('/api/export')
        self.assertEqual(output.status_code, 200)
        self.assertEqual(output.json['portfolio']['selected'][0]['allocation_pct'], 15)
        self.assertEqual(len(output.json['sources']), 3)
        self.assertEqual(output.json['portfolio']['cash_allocation_pct'], 85)
        self.assertEqual(output.json['market_caps']['A']['currency'], 'USD')

    def test_nested_lookup_failure_keeps_snapshot_and_exposes_audit(self):
        state=copy.deepcopy(self.state)
        state['records'][0]['holdings']=[{'name':'Unlinked Fund','symbol':'n/a','kind':'fund'}]
        (self.data/'seed.json').write_text(json.dumps(state))
        with patch.object(server,'scan_record',side_effect=copy.deepcopy):server.run_scan()
        saved=server.load_state()
        self.assertEqual(saved['records'],state['records'])
        self.assertEqual(saved['last_successful_scan'],state['last_successful_scan'])
        api=self.client.get('/api/state').json
        self.assertEqual(api['freshness']['reason'],'lookthrough_required')
        self.assertEqual(len(api['lookup_attempt']['unresolved_records']),1)
        self.assertIn('Unlinked Fund',api['last_attempt']['failures'][0]['message'])
        exported=self.client.get('/api/export').json
        self.assertEqual(exported['latest_holdings_audit'],api['lookup_attempt'])
        self.assertTrue(exported['allocation_status'].startswith('OUTDATED'))

    def test_concurrent_scan_rejected_and_external_origin_rejected(self):
        self.assertEqual(self.client.post('/api/rebalance').status_code, 409)
        self.assertEqual(self.client.post('/api/rebalance', headers={'Origin': 'https://example.org'}).status_code, 403)


if __name__ == '__main__': unittest.main()

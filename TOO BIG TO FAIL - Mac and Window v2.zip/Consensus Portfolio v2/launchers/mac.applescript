on run
    try
        set bundlePath to POSIX path of (path to me)
        set appFolder to do shell script "/usr/bin/dirname " & quoted form of bundlePath
        set launchFile to appFolder & "/Start on Mac.command"
        do shell script "/bin/chmod +x " & quoted form of launchFile
        do shell script "/usr/bin/open -a Terminal " & quoted form of launchFile
    on error messageText
        display dialog "Could not start Consensus Portfolio: " & messageText buttons {"OK"} default button "OK" with icon stop
    end try
end run

#!/bin/zsh
cd "${0:A:h}"
if [[ ! -x .venv/bin/python ]]; then
  python3 -m venv .venv || exit 1
fi
if ! .venv/bin/python -c 'import flask, bs4, pypdf' 2>/dev/null; then
  .venv/bin/python -m pip install --find-links wheels -r requirements.txt || exit 1
fi
if curl --silent --fail http://127.0.0.1:8765/api/state >/dev/null; then
  open http://127.0.0.1:8765
  exit 0
fi
.venv/bin/python app.py &
app_pid=$!
trap 'kill "$app_pid" 2>/dev/null' EXIT INT TERM
for attempt in {1..30}; do
  if curl --silent --fail http://127.0.0.1:8765/api/state >/dev/null; then
    open http://127.0.0.1:8765
    break
  fi
  sleep 0.2
done
wait "$app_pid"
